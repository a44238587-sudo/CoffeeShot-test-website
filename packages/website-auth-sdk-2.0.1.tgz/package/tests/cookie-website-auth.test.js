import assert from "node:assert/strict";
import test from "node:test";

import * as websiteAuth from "../src/index.js";
import { WebsiteAuthError, createCookieWebsiteAuth } from "../src/cookie-client.js";

test("browser SDK exposes the mandatory flow and hides its transport client", () => {
  assert.equal("createWebsiteAuth" in websiteAuth, false);
  assert.equal('createCookieWebsiteAuth' in websiteAuth, false);
  assert.equal(typeof websiteAuth.createWebsiteAuthFlow, 'function');
});

function createAuth() {
  return createCookieWebsiteAuth({
    storageKey: "test.auth.session.v1",
    requestIdPrefix: "test-auth",
    getOAuthCallbackUrl: () => "https://example.com/auth/callback",
    oauthFailureUrl: "/?auth=sign-in",
  });
}

test("cookie client rejects browser payloads that expose bearer or refresh tokens", () => {
  const storage = new Map();
  const previousWindow = globalThis.window;
  globalThis.window = {
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => storage.set(key, value),
      removeItem: key => storage.delete(key),
    },
  };
  try {
    const auth = createAuth();
    assert.throws(
      () =>
        auth.storeAuthResult({
          session: {
            authenticated: true,
            tokenType: "bearer",
            expiresIn: 3600,
            expiresAt: 2_000_000_000,
            accessToken: "must-never-persist",
            refreshToken: "must-never-persist",
          },
          user: {
            id: "11111111-1111-4111-8111-111111111111",
            email: "user@example.com",
            phone: null,
            role: null,
            aud: null,
            emailConfirmedAt: null,
            phoneConfirmedAt: null,
            lastSignInAt: null,
            createdAt: null,
            updatedAt: null,
            displayName: null,
            companyName: null,
            billingName: null,
            billingAddressLine1: null,
            billingAddressLine2: null,
            billingCity: null,
            billingPostalCode: null,
            billingCountryCode: null,
            billingTaxId: null,
          },
        }),
      error =>
        error instanceof WebsiteAuthError && error.code === "auth_cookie_session_invalid"
    );
    assert.equal(storage.size, 0);
  } finally {
    globalThis.window = previousWindow;
  }
});

test('storage-free session restores using cookies and never reads browser storage', async () => {
 const previous = {window:globalThis.window,fetch:globalThis.fetch};
 const forbidden = new Proxy({}, {get(){throw new Error('Browser storage forbidden');}});
 globalThis.window = {localStorage:forbidden,sessionStorage:forbidden,location:{origin:'https://example.com',href:'https://example.com/'}};
 const user={id:'11111111-1111-4111-8111-111111111111',email:'user@example.com'};
 for (const key of ['phone','role','aud','emailConfirmedAt','phoneConfirmedAt','lastSignInAt','createdAt','updatedAt','displayName','companyName','billingName','billingAddressLine1','billingAddressLine2','billingCity','billingPostalCode','billingCountryCode','billingTaxId']) user[key]=null;
 const session={authenticated:true,tokenType:'bearer',expiresIn:3600,expiresAt:Math.floor(Date.now()/1000)+3600};
 const calls=[];
 globalThis.fetch=async (url,options)=>{
  calls.push(String(url));assert.equal(options.credentials,'same-origin');
  return Response.json(String(url).endsWith('/verify')?{ok:true,valid:true,user}:{ok:true,session,user});
 };
 try {
  const auth=createCookieWebsiteAuth({persistSession:false,storageKey:'test.auth',requestIdPrefix:'test-auth',getOAuthCallbackUrl:()=> 'https://example.com/auth/callback',oauthFailureUrl:'/?auth=failed'});
  assert.equal(auth.readStoredSession(),null);
  assert.equal((await auth.getValidStoredSession()).authenticated,true);
  assert.equal((await auth.getValidStoredSession()).user.id,user.id);
  assert.deepEqual(calls.map(s=>s.split('/').slice(-2).join('/')),['token/refresh','auth/verify']);
  auth.clearStoredSession();assert.equal(auth.readStoredSession(),null);
  globalThis.fetch=async()=>Response.json({error:{code:'unauthorized',message:'Signed out'}},{status:401});
  assert.equal(await auth.getValidStoredSession(),null);
 } finally {globalThis.window=previous.window;globalThis.fetch=previous.fetch;}
});

test('email confirmation uses the same-origin facade once and rejects unconfirmed or leaking responses',async()=>{
 const previous={window:globalThis.window,fetch:globalThis.fetch};
 const forbidden=new Proxy({}, {get(){throw Error('Storage must not be used');}});
 globalThis.window={location:{origin:'https://example.com',href:'https://example.com/'},localStorage:forbidden,sessionStorage:forbidden};
 const user={id:'11111111-1111-4111-8111-111111111111',email:'user@example.com'};
 for(const key of ['phone','role','aud','emailConfirmedAt','phoneConfirmedAt','lastSignInAt','createdAt','updatedAt','displayName','companyName','billingName','billingAddressLine1','billingAddressLine2','billingCity','billingPostalCode','billingCountryCode','billingTaxId'])user[key]=null;
 user.emailConfirmedAt='2026-09-12T00:00:00Z';
 const session={authenticated:true,tokenType:'bearer',expiresIn:3600,expiresAt:Math.floor(Date.now()/1000)+3600};
 let calls=0,patch={};
 globalThis.fetch=async(url,options)=>{
  calls++;assert.equal(new URL(url,'https://example.com').pathname,'/api/auth/token/email/confirm');
  assert.equal(options.credentials,'same-origin');assert.deepEqual(JSON.parse(options.body),{tokenHash:'confirmation-token'});
  return Response.json({ok:true,grantType:'email',session,user,...patch});
 };
 try{
  const auth=createCookieWebsiteAuth({persistSession:false,storageKey:'test.auth',requestIdPrefix:'test-confirm',getOAuthCallbackUrl:()=> 'https://example.com/auth/callback',oauthFailureUrl:'/?auth=failed'});
  assert.equal((await auth.confirmEmail('confirmation-token')).user.emailConfirmedAt,user.emailConfirmedAt);
  assert.equal(calls,1);
  await assert.rejects(auth.confirmEmail('bad token'));assert.equal(calls,1);
  patch={user:{...user,emailConfirmedAt:null}};await assert.rejects(auth.confirmEmail('confirmation-token'));assert.equal(calls,2);
  patch={session:{...session,accessToken:'private-secret'}};await assert.rejects(auth.confirmEmail('confirmation-token'));assert.equal(calls,3);
 }finally{globalThis.window=previous.window;globalThis.fetch=previous.fetch;}
});
