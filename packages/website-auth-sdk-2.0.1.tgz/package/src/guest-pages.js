/**
 * Same-origin guest issuance facade. Bind AUTH_GUEST to auth-supabase-app's
 * named GuestAuth entrypoint with immutable appSlug and guestPolicy props.
 * The project identifier is configuration, never arbitrary browser input.
 */
export function createPagesGuestHandler({projectId,bindingName='AUTH_GUEST'}) {
  if(typeof projectId!=='string'||!/^[a-zA-Z0-9_.:@-]{1,160}$/.test(projectId)||typeof bindingName!=='string'||!bindingName)throw new TypeError('Invalid guest Pages configuration.');
  return async ({request,env})=>{
    const rid=request.headers.get('x-request-id');
    const error=(status,code,message)=>Response.json({ok:false,rid:rid||null,error:{code,message,category:status>=500?'dependency':'validation',retryable:status===503}},
      {status,headers:{'cache-control':'no-store',...(rid?{'x-request-id':rid}:{})}});
    if(!rid||rid.length>160||!/^[a-zA-Z0-9_.:@-]+$/.test(rid))return error(500,'guest_request_id_required','A valid request identifier is required.');
    if(request.method!=='POST')return error(405,'guest_method_invalid','Only POST is supported.');
    if(new URL(request.url).search)return error(422,'guest_request_invalid','Query parameters are not supported.');
    if(request.headers.get('origin')!==new URL(request.url).origin)return error(403,'guest_origin_invalid','The request origin is not allowed.');
    if(!request.headers.get('content-type')?.startsWith('application/json'))return error(415,'guest_content_type_invalid','JSON is required.');
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
    const abort=()=>controller.abort();request.signal.addEventListener('abort',abort,{once:true});
    if(request.signal.aborted)controller.abort();
    try {
      const reader=request.body?.getReader();if(!reader)return error(422,'guest_request_invalid','A request body is required.');
      let bytes=0;const chunks=[];
      const cancel=()=>{void reader.cancel().catch(()=>{});};controller.signal.addEventListener('abort',cancel,{once:true});
      try{while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;
        if(bytes>1024){await reader.cancel();return error(413,'guest_request_too_large','The request body is too large.');}chunks.push(value);}}
      finally{controller.signal.removeEventListener('abort',cancel);reader.releaseLock();}
      controller.signal.throwIfAborted();
      const raw=new Uint8Array(bytes);let offset=0;for(const chunk of chunks){raw.set(chunk,offset);offset+=chunk.byteLength;}
      let body;try{body=JSON.parse(new TextDecoder().decode(raw));}catch{return error(422,'guest_request_invalid','The request body is invalid.');}
      if(!body||Object.keys(body).join(',')!=='projectId'||body.projectId!==projectId)return error(422,'guest_project_invalid','The guest project is not allowed.');
      const ip=request.headers.get('cf-connecting-ip');if(!ip)return error(503,'guest_ip_unavailable','Guest access is temporarily unavailable.');
      const binding=env[bindingName];if(!binding?.fetch)return error(503,'guest_service_unavailable','Guest access is temporarily unavailable.');
      const response=await binding.fetch('https://guest.internal/issue',{method:'POST',redirect:'manual',signal:controller.signal,
        headers:{'content-type':'application/json','x-request-id':rid},body:JSON.stringify({projectId,ip})});
      if(response.headers.get('x-request-id')!==rid){await response.body?.cancel();return error(502,'guest_response_invalid','The guest service response is invalid.');}
      // Buffer only the bounded credential envelope; never return a live dependency stream.
      const rr=response.body?.getReader();if(!rr)return error(502,'guest_response_invalid','The guest service response is empty.');
      const output=[];let total=0;
      const cancelResponse=()=>{void rr.cancel().catch(()=>{});};
      controller.signal.addEventListener('abort',cancelResponse,{once:true});
      try{controller.signal.throwIfAborted();while(true){const {done,value}=await rr.read();if(done)break;total+=value.byteLength;if(total>16384){await rr.cancel();return error(502,'guest_response_invalid','The guest service response is invalid.');}output.push(value);}}
      finally{controller.signal.removeEventListener('abort',cancelResponse);rr.releaseLock();}
      controller.signal.throwIfAborted();
      const value=new Uint8Array(total);offset=0;for(const part of output){value.set(part,offset);offset+=part.byteLength;}
      let decoded;try{decoded=JSON.parse(new TextDecoder().decode(value));}catch{return error(502,'guest_response_invalid','The guest service response is invalid.');}
      if(decoded?.rid!==rid)return error(502,'guest_response_invalid','The guest service response is invalid.');
      if(response.status===200){
        const s=decoded.session;
        if(decoded.ok!==true||Object.keys(decoded).sort().join(',')!=='ok,rid,session'||!s||
          Object.keys(s).sort().join(',')!=='expiresAt,projectId,subjectId,token'||s.projectId!==projectId||
          typeof s.token!=='string'||!/^g_[a-f0-9]{64}$/.test(s.token)||typeof s.subjectId!=='string'||!/^guest_[a-f0-9]{32}$/.test(s.subjectId)||
          !Number.isSafeInteger(s.expiresAt)||s.expiresAt<=Date.now())return error(502,'guest_response_invalid','The guest service response is invalid.');
      }else{
        const e=decoded.error;
        if(response.status<400||decoded.ok!==false||Object.keys(decoded).sort().join(',')!=='error,ok,rid'||!e||
          Object.keys(e).sort().join(',')!=='category,code,message,retryable'||typeof e.code!=='string'||
          typeof e.message!=='string'||typeof e.category!=='string'||typeof e.retryable!=='boolean')return error(502,'guest_response_invalid','The guest service response is invalid.');
      }
      const headers=new Headers({'content-type':'application/json','cache-control':'no-store','x-request-id':rid});
      const retry=response.headers.get('retry-after');if(retry&&/^\d+$/.test(retry))headers.set('retry-after',retry);
      return new Response(JSON.stringify(decoded),{status:response.status,headers});
    }catch{return error(503,'guest_service_unavailable','Guest access is temporarily unavailable.');}
    finally{clearTimeout(timer);request.signal.removeEventListener('abort',abort);}
  };
}
