import { createCookieWebsiteAuth } from './cookie-client.js';
import { createFlowController } from './flow-controller.js';

const instances = new Map();

/** One flow per product and browser document. UI remains consumer-owned. */
export function createWebsiteAuthFlow(config) {
  if (typeof config?.signedOutUrl !== 'string' || typeof config.isProtectedRoute !== 'function') {
    throw new TypeError('signedOutUrl and isProtectedRoute are required.');
  }
  if (typeof config.getSuccessUrl !== 'function' || 'oauthSuccessUrl' in config) {
    throw new TypeError('getSuccessUrl is required; oauthSuccessUrl is unsupported.');
  }
  const browser = typeof window !== 'undefined';
  const existing = browser && instances.get(config.storageKey);
  if (existing) return existing;
  const flow = createFlowController(config, createCookieWebsiteAuth(config), {
    url: () => window.location.href,
    now: () => performance.now(),
    wait: ms => new Promise(resolve => window.setTimeout(resolve, ms)),
    replace: url => config.navigate ? config.navigate(url, { replace: true }) : window.location.replace(url),
    assign: url => window.location.assign(url),
  });
  const dispose = flow.dispose;
  const publicFlow = Object.freeze({
    ...flow,
    get state() { return flow.state; },
    dispose() { dispose(); instances.delete(config.storageKey); },
  });
  if (browser) instances.set(config.storageKey, publicFlow);
  return publicFlow;
}

/** Attach once per document; Astro navigation retains the existing controller. */
export function attachWebsiteAuthFlow(flow, document = globalThis.document, window = globalThis.window) {
  if (!document || !window) return () => {};
  const route = () => { void flow.routeChanged().catch(() => {}); };
  const shown = event => { if (event.persisted) void flow.pageShown().catch(() => {}); };
  const storage = event => { if (event.storageArea === window.localStorage) void flow.storageChanged(event.key).catch(() => {}); };
  const visibility = () => { void flow.visibilityChanged(document.visibilityState === 'hidden').catch(() => {}); };
  document.addEventListener('visibilitychange', visibility);
  window.addEventListener('focus', route);
  document.addEventListener('astro:page-load', route);
  window.addEventListener('pageshow', shown);
  window.addEventListener('popstate', route);
  window.addEventListener('storage', storage);
  return () => {
    document.removeEventListener('visibilitychange', visibility);
    window.removeEventListener('focus', route);
    document.removeEventListener('astro:page-load', route);
    window.removeEventListener('pageshow', shown);
    window.removeEventListener('popstate', route);
    window.removeEventListener('storage', storage);
  };
}
