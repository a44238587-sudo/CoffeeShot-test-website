import test from 'node:test';
import assert from 'node:assert/strict';
import { createFlowController } from '../src/flow-controller.js';

function fixture(overrides = {}, configuration = {}) {
  const calls = [];
  const session = { authenticated: true, user: { id: 'user' } };
  const client = {
    prepareGoogleOneTap: async () => {}, readAuthRedirectResult: () => null,
    getValidStoredSession: async () => session,
    storeAuthResult: result => ({ ...result.session, user: result.user }),
    clearStoredSession: () => calls.push('clear'), logout: async () => {},
    loginWithPasswordResult: async () => ({ session, user: session.user }),
    ...overrides,
  };
  const host = { url: () => 'https://example.com/dashboard', now: () => 0,
    wait: async ms => calls.push(['wait', ms]),
    replace: url => calls.push(['replace', url]), assign: url => calls.push(['assign', url]) };
  const config = { getOAuthCallbackUrl: () => 'https://example.com/callback',
    oauthSuccessUrl: '/dashboard', oauthFailureUrl: '/login', signedOutUrl: '/login',
    isProtectedRoute: url => url.pathname === '/dashboard', ...configuration };
  return { flow: createFlowController(config, client, host), calls };
}

test('verification gates rendering and does not add a visual delay', async () => {
  const { flow, calls } = fixture();
  assert.equal(flow.state.canRenderProtected, false);
  await flow.start();
  assert.equal(flow.state.canRenderProtected, true);
  assert.deepEqual(calls, []);
});

test('network failure keeps protected content hidden without signing out', async () => {
  const failure = new Error('offline');
  const { flow, calls } = fixture({ getValidStoredSession: async () => { throw failure; } });
  await assert.rejects(flow.start(), failure);
  assert.equal(flow.state.phase, 'unavailable');
  assert.equal(flow.state.canRenderProtected, false);
  assert.deepEqual(calls, []);
});

test('login starts immediately and holds pending for 600ms before navigation', async () => {
  const { flow, calls } = fixture();
  const login = flow.login('a@example.com', 'password');
  assert.equal(flow.state.busy, true);
  await login;
  assert.deepEqual(calls, [['wait', 600]]);
  assert.equal(flow.state.busy, false);
});

test('logout invalidates a late login response', async () => {
  let resolve;
  const { flow, calls } = fixture({ loginWithPasswordResult: () => new Promise(r => { resolve = r; }) });
  const login = flow.login('a@example.com', 'password');
  const logout = flow.logout();
  assert.equal(flow.state.canRenderProtected, false);
  resolve({ session: { authenticated: true }, user: { id: 'user' } });
  await logout;
  assert.equal(await login, null);
  assert.equal(flow.state.canRenderProtected, false);
  assert.equal(calls.some(call => Array.isArray(call) && call[1].endsWith?.('/dashboard')), false);
});

test('concurrent verifications share one request', async () => {
  let requests = 0;
  const { flow } = fixture({ getValidStoredSession: async () => { requests++; return null; } });
  await Promise.all([flow.verify(), flow.verify()]);
  assert.equal(requests, 1);
});

test('authenticated operations execute once even when rejected', async () => {
  const { flow } = fixture();
  let requests = 0;
  await assert.rejects(flow.runAuthenticated(async () => { requests++; throw new Error('401'); }));
  assert.equal(requests, 1);
});

test('Google dismissal ends pending without redirect', async () => {
  const { flow, calls } = fixture({ isGoogleOneTapReady: () => true,
    offerGoogleOneTap: async handlers => handlers.onPromptDismissed() });
  await flow.oauth('google');
  assert.deepEqual(calls, [['wait', 600]]);
  assert.equal(flow.state.busy, false);
});

test('failed server logout stays signed out and reports the real failure', async () => {
  const error = new Error('remote unavailable');
  const { flow } = fixture({ logout: async () => { throw error; } });
  await flow.start();
  await assert.rejects(flow.logout(), error);
  assert.equal(flow.state.canRenderProtected, false);
  assert.equal(flow.state.error, error);
  assert.equal(await flow.verify(), null);
});

test('a profile update retains its authenticated operation result', async () => {
  const user = { id: 'user', displayName: 'Updated' };
  const { flow } = fixture({ updateAccountProfile: async () => user });
  await flow.start();
  assert.deepEqual(await flow.runAuthenticated(() => flow.updateAccountProfile({ displayName: 'Updated' })), user);
  assert.equal(flow.state.user.displayName, 'Updated');
});

test('a business response arriving after logout is discarded without replay', async () => {
  const { flow } = fixture();
  await flow.start();
  let resolve;
  const request = flow.runAuthenticated(() => new Promise(r => { resolve = r; }));
  // Allow verification to settle and the business operation to start.
  while (!resolve) await Promise.resolve();
  await flow.logout();
  resolve('old account data');
  await assert.rejects(request, error => error.code === 'auth_session_changed');
});

test('configured recovery routes never authorize business initialization', async () => {
  const { flow } = fixture({}, { isRecoveryRoute: () => true });
  await flow.start();
  assert.equal(flow.state.phase, 'recovery');
  assert.equal(flow.state.canRenderProtected, false);
  await assert.rejects(flow.runAuthenticated(() => assert.fail('business must stay blocked')),
    error => error.code === 'auth_session_required');
});

test('callback uses configured navigation without a feedback delay', async () => {
  const { flow, calls } = fixture({ completeOAuthRedirectCallback: async handlers => {
    await handlers.onSuccess({session:{authenticated:true},user:{id:'user'}});
    return true;
  } }, { getSuccessUrl: () => '/account' });
  await flow.completeOAuthRedirectCallback();
  assert.deepEqual(calls, [['replace', 'https://example.com/account']]);
});


test('cross-tab changes reject an earlier verification and recheck the new identity', async () => {
  const pending = [];
  const { flow } = fixture({ invalidateSessionChecks() {},
    getValidStoredSession: () => new Promise(resolve => pending.push(resolve)),
  }, { storageKey: 'account' });
  const old = flow.verify();
  const changed = flow.storageChanged('account');
  pending[1]({ authenticated: true, user: { id: 'second' } });
  await changed;
  pending[0]({ authenticated: true, user: { id: 'first' } });
  assert.equal(await old, null);
  assert.equal(flow.state.user.id, 'second');
});

test('storage-free consumers ignore local storage events', async () => {
  const { flow } = fixture({ getValidStoredSession: () => assert.fail('unexpected request') }, { persistSession: false });
  await flow.storageChanged(null);
});

test('explicit refresh forwards the request without adding delay', async () => {
  const { flow, calls } = fixture({ getValidStoredSession: async options => {
    assert.equal(options.refresh, true); return null;
  } });
  await flow.verify({ refresh: true });
  assert.equal(calls.some(call => call[0] === 'wait'), false);
});

test('Google without synchronous readiness starts redirect immediately', async () => {
  let requests = 0;
  const { flow, calls } = fixture({ isGoogleOneTapReady: () => false,
    startOAuthRedirect: async () => { requests++; return 'https://accounts.google.com/oauth'; },
  });
  const pending = flow.oauth('google');
  assert.equal(requests, 1);
  await pending;
  assert.deepEqual(calls, [['wait', 600], ['assign', 'https://accounts.google.com/oauth']]);
});

test('native success does not fall back after dismissal', async () => {
  const { flow, calls } = fixture({ isGoogleOneTapReady: () => true,
    offerGoogleOneTap: async handlers => {
      handlers.onSuccess({session:{authenticated:true},user:{id:'user'}});
      handlers.onPromptDismissed();
    }, startOAuthRedirect: () => assert.fail('unexpected redirect') });
  await flow.oauth('google');
  assert.equal(flow.state.canRenderProtected, true);
  assert.equal(calls.some(call => call[0] === 'assign'), false);
});

test('provider failure is preserved in observable state', async () => {
  const failure = new Error('provider unavailable');
  const { flow } = fixture({ isGoogleOneTapReady: () => false,
    startOAuthRedirect: async () => { throw failure; } });
  await assert.rejects(flow.oauth('google'), failure);
  assert.equal(flow.state.error, failure);
  assert.equal(flow.state.busy, false);
});


test('hidden gated views discard late verification before resuming', async()=>{
 const pending=[];const {flow}=fixture({getValidStoredSession:()=>new Promise(resolve=>pending.push(resolve))},{gateWhenHidden:true});
 const checking=flow.verify();await flow.visibilityChanged(true);
 pending[0]({authenticated:true,user:{id:'old'}});assert.equal(await checking,null);
 assert.equal(flow.state.canRenderProtected,false);
 const resume=flow.visibilityChanged(false);pending[1]({authenticated:true,user:{id:'current'}});await resume;
 assert.equal(flow.state.user.id,'current');
});
test('asynchronous product destinations complete before SDK navigation',async()=>{
 const {flow,calls}=fixture({}, {getSuccessUrl:async()=>'/draft/resume'});
 await flow.login('a@example.com','password');
 assert.deepEqual(calls.at(-1),['replace','https://example.com/draft/resume']);
});

test('a repeated callback shares one exchange', async () => {
  let exchanges = 0;
  const {flow} = fixture({completeOAuthRedirectCallback: async () => {exchanges++;}});
  await Promise.all([flow.completeOAuthRedirectCallback(), flow.completeOAuthRedirectCallback()]);
  assert.equal(exchanges, 1);
});

test('captcha preparation owns immediate busy feedback and stops failed submissions', async () => {
  let sent = 0;
  let reject;
  const failure = new Error('captcha unavailable');
  const {flow} = fixture({loginWithPasswordResult: async () => {sent++;}}, {
    getCaptchaToken: () => new Promise((resolve, fail) => {reject=fail;}),
  });
  const pending=flow.login('a@example.com','password');
  assert.equal(flow.state.busy,true);
  reject(failure);
  await assert.rejects(pending,failure);
  assert.equal(sent,0);
  assert.equal(flow.state.error,failure);
});

test('focus verification cannot reveal hidden navigation', async () => {
  const {flow} = fixture({}, {gateWhenHidden:true});
  await flow.start();
  await flow.visibilityChanged(true);
  await flow.routeChanged();
  assert.equal(flow.state.canRenderProtected,false);
  await flow.visibilityChanged(false);
  assert.equal(flow.state.canRenderProtected,true);
});

test('existing verified sessions leave configured authentication routes', async () => {
  const {flow,calls} = fixture({}, {isAuthRoute:()=>true, getSuccessUrl:()=>'/projects'});
  await flow.start();
  assert.deepEqual(calls,[['replace','https://example.com/projects']]);
});


test('late callback completion cannot restore a logged-out session', async () => {
  let complete;
  const {flow,calls} = fixture({completeOAuthRedirectCallback: handlers => new Promise(resolve => {
    complete = async () => { await handlers.onSuccess({session:{authenticated:true},user:{id:'old'}}); resolve(); };
  })}, {oauthSuccessUrl:'/account'});
  const callback=flow.completeOAuthRedirectCallback();
  const logout=flow.logout();
  await complete();
  await Promise.all([callback,logout]);
  assert.equal(flow.state.canRenderProtected,false);
  assert.equal(calls.some(call=>call[1]==='https://example.com/account'),false);
});

test('late business failures cannot invalidate a replacement identity', async () => {
  let reject;
  const {flow}=fixture();
  await flow.start();
  const pending=flow.runAuthenticated(()=>new Promise((resolve,fail)=>{reject=fail;}));
  while(!reject) await Promise.resolve();
  await flow.logout();
  await flow.login('new@example.com','password');
  reject(Object.assign(new Error('old request unauthorized'),{status:401}));
  await assert.rejects(pending,error=>error.code==='auth_session_changed');
  assert.equal(flow.state.canRenderProtected,true);
});

test('cancelled captcha preparation cannot send a later login request', async () => {
  let complete;let requests=0;
  const {flow}=fixture({loginWithPasswordResult:async()=>{requests++;}}, {
    getCaptchaToken:()=>new Promise(resolve=>{complete=resolve;}),
  });
  const login=flow.login('a@example.com','password');
  const rejected=assert.rejects(login,error=>error.name==='AbortError');
  const logout=flow.logout();
  complete('captcha');
  await Promise.all([rejected,logout]);
  assert.equal(requests,0);
  assert.equal(flow.state.canRenderProtected,false);
});
