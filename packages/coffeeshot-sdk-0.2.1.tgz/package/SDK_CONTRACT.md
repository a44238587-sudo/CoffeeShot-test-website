# CoffeeShot SDK Contract

This is the public contract for the headless CoffeeShot browser SDK.
CoffeeShot provides camera framing guidance and still-photo analysis.

The SDK is intentionally smaller than Dictum SDK. It does not include
speech-to-text, WebSockets, identity, or Workers.

## CDN quick start

The preferred host integration loads the awaitable Cloudflare Pages module:

```js
const sdkOrigin = 'https://coffeeshot-sdk.pages.dev';
const { checkCompatibility, createClient } = await import(
  `${sdkOrigin}/sdk.mjs`
);

const compatibility = checkCompatibility();
if (!compatibility.supported) {
  throw new Error(compatibility.reason ?? 'Camera is unavailable.');
}

const client = createClient({
  apiUrl: 'https://api.example.com', // optional
  analyzePath: '/analyze',
  previewElement: '#preview',
  overlay: true,
  locale: 'fr',
});

client.on('*', (event) => console.log(event.type, event.data));
await client.start();
await client.flip();
const still = await client.capture(); // kicks analyze; result arrives as `result`
await client.stop();
client.destroy();
```

A host can also copy `dist/sdk.mjs` next to its own assets and import that file.
No secrets belong in the browser bundle. The API origin is host-provided config.

## Exports

The bundle entry (`src/index.ts` → `dist/sdk.mjs`) exports:

| Name | Kind |
| --- | --- |
| `checkCompatibility` | function |
| `createClient` | function |
| `CoffeeShotError` | class |
| `FRAMING_GUIDES` | constant |

TypeScript declarations are emitted next to the bundle as `dist/sdk.d.ts`.

## `checkCompatibility()`

Synchronous. Does not request the camera or create a client.

```ts
type CompatibilityReport = {
  supported: boolean;
  reason?: 'not_browser' | 'insecure_context' | 'no_media_devices';
  cameras?: number;
};
```

- `supported: true` when `window.isSecureContext` and `navigator.mediaDevices.getUserMedia` exist.
- `cameras` is omitted here (device enumeration is async). The `ready` event and `start()` result include a camera count when the browser reports one.

## `createClient(config?)`

Returns a reusable `CoffeeShotClient`. Construction is synchronous and does not call `getUserMedia`.

```ts
type CoffeeShotClientConfig = {
  apiUrl?: string;            // backend origin; mock analysis when omitted
  analyzePath?: string;       // default `/analyze`
  previewElement?: HTMLVideoElement | string;
  overlay?: boolean | HTMLElement | string;
  locale?: 'fr' | 'en';       // default `fr`
  source?: string;            // multipart field; default `coffeeshot-sdk`
  quality?: number;           // JPEG 0–1; default `0.85`
  hintIntervalMs?: number;    // default `3200`
};
```

Invalid `locale`, `quality`, or `hintIntervalMs` throw `CoffeeShotError` with code `invalid_config`.

## Client lifecycle

```
idle → starting → previewing ⇄ flipping
                 ↘ capturing → analyzing → previewing
previewing / analyzing → stopped
any live state → destroyed
```

| Method | Behavior |
| --- | --- |
| `start()` | Request the camera (unless `{ demo: true }`), attach the preview, start hint rotation, emit `ready`. |
| `flip()` | Stop every track on the current `MediaStream`, remount the preview, open the other facing. Never leaves a dead stream. |
| `capture()` | Encode a JPEG still from the live video (or a generated demo still). Returns `{ blob, uri }` and **starts** `analyze()` without blocking on it. |
| `analyze(blob?)` | Multipart POST to `{apiUrl}{analyzePath}` or a local mock. Uses the last capture when no input is given. |
| `stop()` | Stop tracks, detach `srcObject`, stop hints, and unmount the optional overlay. The client can `start()` again. |
| `destroy()` | `stop()` plus overlay teardown, listener removal, and object-URL revoke. Further commands throw `destroyed`. |

Commands are serialized on one client. A second overlapping command rejects with `busy` only if it races the in-flight lock; queued calls wait.

`start()` is idempotent while already `starting` / `previewing`.

## Camera and flip rules

- Preview is an existing host `<video>` (element or selector). The SDK does not invent a hidden video unless the host attaches one.
- `start()` uses `getUserMedia` with `facingMode` (`environment` for `back`, `user` for `front`) and `deviceId` when a second camera is known.
- Before every facing change the SDK:
  1. Stops all tracks on the current stream
  2. Clears `video.srcObject` and calls `video.load()` (remount)
  3. Waits ~80ms so the browser can release the device
  4. Opens the next stream and calls `video.play()`
- If `enumerateDevices()` reports fewer than two `videoinput` devices, `flip()` does **not** tear down the live preview. It returns `{ flipped: false, reason: 'single_camera' }` and emits `banner`.
- If the other camera fails to open, the SDK restores the previous facing when possible, emits `banner` (`unavailable`), and returns `{ flipped: false, reason: 'unavailable' }`.
- `stop()` / `destroy()` always stop leftover tracks. `start()` / `flip()` abort after `getUserMedia` if the client was destroyed in the meantime, and they stop that new stream.

## Framing

`client.getFraming()` returns data the host can render:

```ts
{
  guides: { thirds: { x: [1/3, 2/3], y: [1/3, 2/3] } },
  hint: string,
  hintIndex: number,
  facing: 'front' | 'back',
  banner?: string
}
```

`FRAMING_GUIDES` is the same thirds grid.

Hints rotate while the session is live (`hint` events). Default copy is French.

`overlay: true` (or an element / selector) mounts an optional DOM helper: rule-of-thirds lines, corner brackets, hint chip, and banner. The overlay is `pointer-events: none`. Hosts that want a custom UI can ignore the helper and render from `getFraming()` / `hint` events.

## Analyze

When `apiUrl` is set, the SDK `POST`s `multipart/form-data` to `{apiUrl}{analyzePath}`:

| Field | Value |
| --- | --- |
| `image` | captured JPEG |
| `source` | `coffeeshot-sdk` unless configured |

Upload progress is reported on `status` (`status: 'analyzing', progress`). The preferred transport is `XMLHttpRequest` so progress events exist; `fetch` is the fallback.

A JSON body such as `{ "title", "score", "tips" }` is normalized to:

```ts
type AnalyzeResult = {
  source: 'api' | 'mock';
  title: string;
  score?: number;
  tips: string[];
  raw?: unknown;
};
```

When `apiUrl` is omitted, analysis is a local mock (`source: 'mock'`) and a `banner` explains that no API is configured. No backend URL is hardcoded in the bundle.

## Events

`client.on(event, handler)` returns an unsubscribe function.

| Event | `data` |
| --- | --- |
| `ready` | `{ facing, cameras?, demo }` |
| `hint` | `{ text, index }` |
| `status` | `{ status, progress?, message? }` |
| `banner` | `{ message, reason }` |
| `result` | `AnalyzeResult` |
| `error` | `{ code, message }` |
| `*` | any of the above (`event.type` + `event.data`) |

`status` values: `idle` | `starting` | `previewing` | `flipping` | `capturing` | `analyzing` | `stopped` | `destroyed`.

Banner reasons: `single_camera` | `unavailable` | `mock_api` | `demo` | `custom`.

## Errors

`CoffeeShotError` has a stable `code`:

| Code | When |
| --- | --- |
| `unsupported` | Compatibility failed |
| `permission_denied` | User or browser blocked the camera |
| `camera_unavailable` | No device, overconstrained, or unreadable |
| `not_started` | Camera command before `start()` |
| `destroyed` | Command after `destroy()` |
| `busy` | Overlapping command lock |
| `capture_failed` | Still encode failed or no preview |
| `analyze_failed` | Upload / parse / missing still |
| `invalid_config` | Bad `createClient` options |

Errors also emit `error`. `capture()` still returns the JPEG if only analysis fails later.

## Demo mode

`await client.start({ demo: true })` skips `getUserMedia`. `capture()` returns a generated still and still runs mock or remote analysis. `flip()` is a no-op with `reason: 'demo'`.

## Deploy

The remote Cloudflare Pages build writes a Pages-ready `dist/`:

- `dist/sdk.mjs` — CDN entry
- `dist/sdk.d.ts` — types barrel
- `dist/index.html` — optional demo
- `dist/_headers` — CORS for cross-origin `import()`
- `dist/SDK_CONTRACT.md`

Publish the complete canonical `main` worktree from this repository:

```sh
github-publish-main "docs: maintain SDK contract [cloudflare:full]"
```

The Git-connected `coffeeshot-sdk` Pages project runs `npm run build:cloudflare`
and publishes `dist`. Fast is the default; one `[cloudflare:full]` subject marker
adds remote TypeScript and SDK contract tests after the build. The publisher
waits for the exact commit's terminal deployment result. Local builds and tests
are disabled; the published module is https://coffeeshot-sdk.pages.dev/sdk.mjs.

## Natural photo API (0.2.1)

`createPhotoSession({video,guidanceUrl,onGuidance,onError})` owns camera access.
Call `start()` from a user gesture, `guide(true)` after explicit preview consent,
`capture()` for `{original,corrected,width,height,adjustments}`, and `destroy()` on disposal.
Guidance uses a same-origin cookie-authenticated POST gateway to CoffeeFrame
`/photo/guidance`. Multipart: JPEG `image` <=131072 bytes, UUID `frameId`,
`locale=en|fr`; response `{ok:true,rid,frameId,guidance:{message,ready}}`.
A 512px preview is sent, one request at a time, waiting 3 seconds after each reply.
Failures pause guidance; hidden pages stop camera and guidance. No latency guarantee.

`correctPhotoBlob(blob,{signal?})` retains the original and corrects a <=1600px
JPEG copy locally. Supported sources: JPEG/PNG/WebP, <=20MB. Exposure,
white balance, contrast, saturation and sharpening stay bounded; no generation,
geometry changes, additions or removals. Algorithm analyzes pixels, not model edits.
`coffeeshot-sdk/native` exports `correctPhoto`, `inspectPhoto`, `createGuidanceLoop`
and `readPhotoGuidance`. Host owns Expo capture/codecs/transport. RGBA <=2,560,000
pixels. Cancellation errors reject; inputs are not mutated.
`createGuidanceLoop({capture,analyze,onGuidance,onError,intervalMs?})` returns
`start`, `stop`, `settle`, `running`; interval is 3000–60000ms after each result.
No automatic retry after failure. Stop suppresses stale responses. Capture adapters
must settle their promises even when cancellation cannot interrupt a native capture.

Immutable package: `/coffeeshot-sdk-0.2.1.tgz`; browser `/sdk.mjs`.
Legacy `createClient` demo analysis remains explicitly mock; new photo integrations
use `createPhotoSession` or the native core, never legacy mock results.
