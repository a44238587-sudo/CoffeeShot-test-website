import test from 'node:test';
import assert from 'node:assert/strict';
import {createGuestSession} from '../src/guest.js';

function response(init,now,overrides={}) {
  const rid=init.headers['x-request-id'];
  return Response.json({ok:true,rid,session:{projectId:'demo',subjectId:'guest_'+'a'.repeat(32),token:'g_'+'b'.repeat(64),expiresAt:now+3600000,...overrides}},{headers:{'x-request-id':rid}});
}

test('guest initialization makes no call; interactions deduplicate and reuse identity',async()=>{
  let calls=0;const now=Date.now();
  const guest=createGuestSession({endpoint:'https://api.example/guest',projectId:'demo',now:()=>now,fetch:async(url,init)=>{calls++;return response(init,now);}});
  assert.equal(calls,0);assert.equal(guest.state.phase,'idle');
  const [a,b]=await Promise.all([guest.ensure(),guest.ensure()]);
  assert.equal(calls,1);assert.equal(a,b);assert.equal(await guest.ensure(),a);
  guest.authenticated();assert.equal(guest.state.session,null);assert.equal(calls,1);
  guest.dispose();
});

test('late guest response cannot restore identity after sign-in',async()=>{
  let finish;const now=Date.now();
  const guest=createGuestSession({endpoint:'https://api.example/guest',projectId:'demo',now:()=>now,
    fetch:async(url,init)=>{await new Promise(resolve=>{finish=resolve;});return response(init,now);}});
  const pending=guest.ensure();guest.authenticated();finish();
  await assert.rejects(pending,{code:'guest_session_changed'});
  assert.equal(guest.state.session,null);guest.dispose();
});

test('guest response rejects cross-project identities and preserves quota refusal',async()=>{
  const now=Date.now();
  const invalid=createGuestSession({endpoint:'https://api.example/guest',projectId:'demo',now:()=>now,fetch:async(url,init)=>response(init,now,{projectId:'other'})});
  await assert.rejects(invalid.ensure(),{code:'guest_response_invalid'});invalid.dispose();
  const blocked=createGuestSession({endpoint:'https://api.example/guest',projectId:'demo',fetch:async(url,init)=>{
    const rid=init.headers['x-request-id'];
    return Response.json({ok:false,rid,error:{code:'QUOTA_API.REQUEST_RATE_LIMITED',message:'Limit reached.',category:'quota',retryable:true}},
      {status:429,headers:{'x-request-id':rid,'retry-after':'60'}});
  }});
  await assert.rejects(blocked.ensure(),{code:'QUOTA_API.REQUEST_RATE_LIMITED',status:429,retryAfter:60});blocked.dispose();
});
