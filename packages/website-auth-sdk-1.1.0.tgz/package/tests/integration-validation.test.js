import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { validateWebsiteAuthIntegration } from '../src/validate-integration.js';

test('integration validation distinguishes Svelte state from controller methods', () => {
  const root = mkdtempSync(join(tmpdir(), 'auth-contract-'));
  mkdirSync(join(root, 'src'));
  const path = join(root, 'src', 'app.svelte');
  const source = `const websiteAuth = createWebsiteAuthFlow(config);
attachWebsiteAuthFlow(websiteAuth); websiteAuth.subscribe(render); websiteAuth.start();
const storageKey = 'product.auth.session';
{#if $websiteAuth.canRenderProtected}<main />{/if}`;
  try {
    writeFileSync(path, source);
    assert.equal(validateWebsiteAuthIntegration(root).files, 1);
    writeFileSync(path, source + '\nwebsiteAuth.getValidStoredSession();');
    assert.throws(() => validateWebsiteAuthIntegration(root), /unsupported flow member getValidStoredSession/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});
