import test from 'node:test';
import assert from 'node:assert/strict';
import { createCookieWebsiteAuth } from '../src/cookie-client.js';
import { createCookiePagesAuthHandler } from '../src/cloudflare-pages.js';
const rid = 'recovery-test-1';
const token = 'a'.repeat(64);
const expiry = () => Date.now() + 600000;
const config = origin => ({ appSlug: 'test-app', recovery: { enabled: true, returnUrls: [`${origin}/auth/reset-password/`], contextMaxAgeSeconds: 600 } });
function context(origin, path, body, fetch, options = {}) {
  return { params: {path: path.split('/')}, request: new Request(`${origin}/api/auth/${path}`, {
    method: options.method ?? 'POST', headers: {'content-type':'application/json', 'x-request-id':rid, origin, ...options.headers},
    ...((options.method ?? 'POST') === 'POST' ? {body:typeof body === 'string' ? body : JSON.stringify(body)} : {}) }), env: {AUTH_SUPABASE_APP: {fetch}} };
}
const grant = () => ({ok:true,rid,grantType:'recovery',recoveryToken:token,expiresAt:expiry(),email:'test@example.invalid'});
test('recovery projects only a temporary HttpOnly credential on either website, never normal session cookies',async()=>{
  for (const origin of ['https://one.example','https://two.example']) {
    const handler=createCookiePagesAuthHandler(config(origin));
    const response=await handler(context(origin,'token/password/recovery/verify',{tokenHash:'proof'},async request=>{
      assert.equal(request.headers.get('x-request-id'),rid);assert.equal(request.headers.get('authorization'),null);
      assert.deepEqual(await request.json(),{tokenHash:'proof'});return Response.json(grant());
    },{headers:{cookie:'__Host-test-app-access=another-user; __Host-test-app-refresh=another-refresh'}}));
    assert.equal(response.status,200);const body=await response.json();assert.equal(body.authorized,true);
    assert.equal(JSON.stringify(body).includes(token),false);
    const cookie=response.headers.get('set-cookie');assert.match(cookie,/__Host-test-app-recovery=/);assert.match(cookie,/HttpOnly/);assert.doesNotMatch(cookie,/test-app-access|test-app-refresh/);
  }
});
test('recovery rejects GET, CSRF, unconfigured use and arbitrary redirects without upstream consumption',async()=>{
  const origin='https://one.example';const handler=createCookiePagesAuthHandler(config(origin));let calls=0;const fetch=async()=>{calls++;return Response.json(grant());};
  for(const [path,body,options,status] of [
    ['token/password/recovery/verify',{tokenHash:'proof'},{method:'GET'},405],
    ['token/password/recovery/verify',{tokenHash:'proof'},{headers:{origin:'https://attacker.example'}},403],
    ['token/password/recover',{email:'test@example.invalid',redirectTo:'https://attacker.example/'},{},422],
    ['token/password/recovery/complete',{password:'password-test'},{headers:{cookie:'__Host-test-app-access=normal-access'}},401]
  ]) assert.equal((await handler(context(origin,path,body,fetch,options))).status,status);
  assert.equal((await createCookiePagesAuthHandler({appSlug:'test-app'})(context(origin,'token/password/recover',{},fetch))).status,503);
  assert.equal(calls,0);
});
test('recovery context reload and completion use only the recovery credential, keep duplicate JSON for backend rejection',async()=>{
  const origin='https://one.example', handler=createCookiePagesAuthHandler(config(origin));
  for(const path of ['token/password/recovery/context','token/password/recovery/complete']) {
    const response=await handler(context(origin,path,path.endsWith('context')?{}:{password:'new password'},async request=>{
      assert.equal(request.headers.get('authorization'),`Bearer ${token}`);
      return Response.json(path.endsWith('context')?{ok:true,rid,authorized:true,expiresAt:expiry(),email:'verified@example.invalid'}:{ok:true,rid,authorized:false,passwordUpdated:true,sessionsRevoked:true});
    },{headers:{cookie:`__Host-test-app-recovery=${token}; __Host-test-app-access=other-user`}}));
    assert.equal(response.status,200);assert.doesNotMatch(response.headers.get('set-cookie')??'',/test-app-access/);
  }
  const raw='{"tokenHash":"first","tokenHash":"second"}';
  await handler(context(origin,'token/password/recovery/verify',raw,async request=>{assert.equal(await request.text(),raw);return Response.json({ok:false,rid,error:{code:'AUTH_APP.INVALID_BODY',category:'validation',message:'private',retryable:false}},{status:400});}));
});
test('uncertain verification is not retried, raw provider diagnostics are not projected',async()=>{
  let calls=0;const handler=createCookiePagesAuthHandler(config('https://one.example'));
  const response=await handler(context('https://one.example','token/password/recovery/verify',{tokenHash:'proof'},async()=>{calls++;throw Error('secret proof');}));
  assert.equal(calls,1);const result=await response.json();assert.equal(result.error.code,'AUTH_APP.RECOVERY_UNCERTAIN');assert.equal(result.error.retryable,false);assert.equal(JSON.stringify(result).includes('secret'),false);
});
test('browser recovery works with persistSession false and without any browser storage or PKCE',async()=>{
  const original=globalThis.fetch;const calls=[];
  globalThis.fetch=async(url,init)=>{calls.push([url,JSON.parse(init.body)]);return Response.json(url.endsWith('/recover')?{ok:true,recoveryRequested:true}:url.endsWith('/clear')?{ok:true,cleared:true}:{ok:true,authorized:true,expiresAt:expiry(),email:null});};
  try {
    const client=createCookieWebsiteAuth({persistSession:false,storageKey:'fixture',requestIdPrefix:'fixture',getOAuthCallbackUrl:()=> 'https://one.example/oauth/',oauthSuccessUrl:'/',oauthFailureUrl:'/',recovery:{enabled:true,returnUrl:'https://one.example/auth/reset-password/',successUrl:'/login/',errorUrl:'/reset/'}});
    await client.requestPasswordRecovery('test@example.invalid');await client.verifyPasswordRecovery('proof');await client.getPasswordRecoveryContext();
    assert.equal(calls.length,4);assert.equal(calls[0][1].redirectTo,'https://one.example/auth/reset-password/');assert.equal(calls.every(([url])=>url.startsWith('/api/auth/')),true);
    assert.equal(client.readStoredSession(),null);
  } finally {globalThis.fetch=original;}
});
