import test from 'node:test';
import assert from 'node:assert/strict';
import {createPagesGuestHandler} from '../src/guest-pages.js';

function request(body={projectId:'demo'},headers={}) {
  return new Request('https://site.example/api/guest',{method:'POST',headers:{origin:'https://site.example','content-type':'application/json','x-request-id':'guest-test','cf-connecting-ip':'192.0.2.1',...headers},body:JSON.stringify(body)});
}
test('Pages guest facade owns project and forwards only platform IP',async()=>{
  const handler=createPagesGuestHandler({projectId:'demo'});let calls=0;
  const env={AUTH_GUEST:{fetch:async(url,init)=>{
    calls++;assert.equal(url,'https://guest.internal/issue');
    assert.deepEqual(JSON.parse(init.body),{projectId:'demo',ip:'192.0.2.1'});
    return Response.json({ok:true,rid:'guest-test',session:{projectId:'demo',subjectId:'guest_'+'a'.repeat(32),token:'g_'+'b'.repeat(64),expiresAt:Date.now()+60000}},{headers:{'x-request-id':'guest-test'}});
  }}};
  assert.equal((await handler({request:request(),env})).status,200);
  assert.equal((await handler({request:request({projectId:'other'}),env})).status,422);
  assert.equal((await handler({request:request({projectId:'demo',ip:'spoofed'}),env})).status,422);
  assert.equal((await handler({request:request(undefined,{origin:'https://other.example'}),env})).status,403);
  assert.equal(calls,1);
});
test('Pages guest facade retains quota retry delay and rejects malformed dependency',async()=>{
  const handler=createPagesGuestHandler({projectId:'demo'});
  const env={AUTH_GUEST:{fetch:async()=>Response.json({ok:false,rid:'guest-test',error:{code:'QUOTA_API.REQUEST_RATE_LIMITED',message:'Limit reached.',category:'quota',retryable:true}},
    {status:429,headers:{'x-request-id':'guest-test','retry-after':'60'}})}};
  const result=await handler({request:request(),env});assert.equal(result.status,429);assert.equal(result.headers.get('retry-after'),'60');
  env.AUTH_GUEST.fetch=async()=>Response.json({secret:'must-not-forward'},{headers:{'x-request-id':'guest-test'}});
  const failed=await handler({request:request(),env});assert.equal(failed.status,502);assert.doesNotMatch(await failed.text(),/must-not-forward/);
});
