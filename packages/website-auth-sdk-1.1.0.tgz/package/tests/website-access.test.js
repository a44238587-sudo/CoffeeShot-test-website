import assert from 'node:assert/strict';
import test from 'node:test';
import { createPagesAccessGuard, createPagesAuthHandler } from '../src/cloudflare-pages.js';

const email = 'owner@example.com';
const options = { appSlug: 'test-product', allowedEmail: email };
const rid = 'website-access-test';
const user = { id: '11111111-1111-4111-8111-111111111111', email, emailConfirmedAt: '2026-01-01T00:00:00Z' };
for (const field of ['phone', 'role', 'aud', 'phoneConfirmedAt', 'lastSignInAt', 'createdAt', 'updatedAt', 'displayName', 'companyName', 'billingName', 'billingAddressLine1', 'billingAddressLine2', 'billingCity', 'billingPostalCode', 'billingCountryCode', 'billingTaxId']) user[field] = null;
function context(fetch, cookie = '__Host-test-product-access=trusted-session') {
  return {
    request: new Request('https://test.example/api/private', { headers: { cookie, 'x-request-id': rid } }),
    env: { AUTH_SUPABASE_APP: { fetch } },
  };
}
function verified(value = user) {
  return Response.json({ ok: true, rid, valid: true, reason: 'ok', user: value });
}

test('access guard permits only the confirmed owner identity from the service', async () => {
  const guard = createPagesAccessGuard(options);
  const allowed = await guard(context(async request => {
    assert.equal(request.url, 'https://auth-supabase-app.internal/test-product/verify');
    assert.equal(request.headers.get('authorization'), 'Bearer trusted-session');
    assert.deepEqual(await request.json(), { includeUser: true });
    return verified();
  }));
  assert.equal(allowed, null);
  for (const deniedUser of [{ ...user, email: 'other@example.com' }, { ...user, emailConfirmedAt: null }, {}, null]) {
    const denied = await guard(context(() => verified(deniedUser)));
    assert.equal(denied.status, 403);
    assert.equal((await denied.json()).error.code, 'website_access_denied');
    assert.match(denied.headers.get('set-cookie'), /Max-Age=0/);
  }
});

test('access guard rejects absent sessions and fails closed on verification errors', async () => {
  const guard = createPagesAccessGuard(options);
  assert.equal((await guard(context(() => { throw new Error('must not call'); }, ''))).status, 401);
  for (const fetch of [() => { throw new Error('offline'); }, () => Response.json({ ok: true }), () => new Response('unavailable', { status: 503 })]) {
    assert.equal((await guard(context(fetch))).status, 502);
  }
  assert.throws(() => createPagesAccessGuard({ appSlug: 'test-product' }), TypeError);
  for (const allowedEmail of [null, '', ' owner@example.com', '*', 1]) {
    assert.throws(() => createPagesAuthHandler({ ...options, allowedEmail }), TypeError);
  }
});

test('restricted account writes stop before mutation for another account', async () => {
  const handler = createPagesAuthHandler(options);
  const ctx = context(request => {
    assert.match(request.url, /\/verify$/);
    return verified({ ...user, email: 'other@example.com' });
  });
  ctx.request = new Request('https://test.example/api/auth/account/profile', {
    method: 'POST', headers: ctx.request.headers, body: '{}',
  });
  ctx.params = { path: ['account', 'profile'] };
  assert.equal((await handler(ctx)).status, 403);
});

test('restricted verification always asks the service for the verified user', async () => {
  const handler = createPagesAuthHandler(options);
  const ctx = context(async request => {
    assert.deepEqual(await request.json(), { includeUser: true });
    return verified({ ...user, email: 'other@example.com' });
  });
  ctx.request = new Request('https://test.example/api/auth/verify', {
    method: 'POST', headers: ctx.request.headers, body: '{"includeUser":false}',
  });
  ctx.params = { path: ['verify'] };
  assert.equal((await handler(ctx)).status, 403);
});

test('restricted session grants verify the new token before issuing cookies', async () => {
  for (const identity of [user, { ...user, email: 'other@example.com' }]) {
    const requests = [];
    const ctx = context(request => {
      requests.push(request.url);
      if (request.url.endsWith('/verify')) {
        assert.equal(request.headers.get('authorization'), 'Bearer newly-issued-access');
        return verified(identity);
      }
      return Response.json({ ok: true, rid, user, session: {
        accessToken: 'newly-issued-access', refreshToken: 'newly-issued-refresh',
        tokenType: 'bearer', expiresIn: 3600, expiresAt: 2000000000,
      } });
    });
    ctx.request = new Request('https://test.example/api/auth/token/refresh', {
      method: 'POST', headers: { 'x-request-id': rid, cookie: '__Host-test-product-refresh=old-refresh' }, body: '{}',
    });
    ctx.params = { path: ['token', 'refresh'] };
    const response = await createPagesAuthHandler(options)(ctx);
    assert.equal(requests.length, 2);
    assert.equal(response.status, identity.email === email ? 200 : 403);
    const cookies = response.headers.get('set-cookie');
    if (identity.email === email) assert.match(cookies, /newly-issued-access/);
    else assert.doesNotMatch(cookies, /newly-issued/);
  }
});

test('website middleware gates documents, assets and APIs before downstream execution', async () => {
  const { createPagesWebsiteGuard } = await import('../src/cloudflare-pages.js');
  const guard = createPagesWebsiteGuard({ ...options, signInPath: '/test-access/', publicPaths: ['/test-access/', '/test-access/login.js'] });
  for (const path of ['/', '/api/private', '/private.json', '/assets/app.js']) {
    const ctx = context(() => verified({ ...user, email: 'other@example.com' }));
    ctx.request = new Request(`https://test.example${path}`, { headers: ctx.request.headers });
    ctx.next = () => { throw new Error('unauthorized downstream invocation'); };
    assert.equal((await guard(ctx)).status, 403);
  }
  for (const path of ['/test-access/', '/test-access/login.js', '/api/auth/token/password/login']) {
    const ctx = context(() => { throw new Error('public route must not verify'); });
    ctx.request = new Request(`https://test.example${path}`);
    ctx.next = () => new Response('login route');
    assert.equal(await (await guard(ctx)).text(), 'login route');
  }
  const anonymous = context(() => { throw new Error('missing token must not verify'); }, '');
  anonymous.request = new Request('https://test.example/', { headers: { accept: 'text/html' } });
  anonymous.next = () => { throw new Error('must not serve private document'); };
  const redirect = await guard(anonymous);
  assert.equal(redirect.status, 303);
  assert.equal(redirect.headers.get('location'), '/test-access/');
  const owner = context(() => verified());
  owner.next = () => new Response('private page', { headers: { 'cache-control': 'public, max-age=3600' } });
  const allowed = await guard(owner);
  assert.equal(await allowed.text(), 'private page');
  assert.equal(allowed.headers.get('cache-control'), 'private, no-store');
  assert.throws(() => createPagesWebsiteGuard({ ...options, signInPath: '/', publicPaths: ['/'] }), TypeError);
});
