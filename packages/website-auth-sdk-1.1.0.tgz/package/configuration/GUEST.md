# Optional guest sessions

Import `createGuestSession` from `website-auth-sdk/guest`. This headless module
does not initialize account authentication or change the site's visual design.
Construction and subscription perform no network request. Call `ensure()` only
when the visitor requests a guest operation, never during page or widget loading.

```js
import { createGuestSession } from 'website-auth-sdk/guest';
const guest = createGuestSession({
  endpoint: 'https://your-product-api.example/guest',
  projectId: 'your-server-registered-project'
});
// Inside the explicit user action:
const session = await guest.ensure();
// Pass the session to the product SDK's documented guest adapter.
// After verified account sign-in:
guest.authenticated();
```

The endpoint is owned by the product and delegates issuance to shared auth.
It accepts `{projectId}` and responds with `{ok:true,rid,session}` and matching
`X-Request-Id`. Session fields: `projectId`, `subjectId` (`guest_` plus 32 lowercase
hex characters), `token` (`g_` plus 64 lowercase hex characters), and integer
`expiresAt` (Unix milliseconds). The browser never selects its subject or quotas.

Guest bearer credentials are intentionally memory-only, distinct from account
access/refresh tokens, which remain in HttpOnly cookies. A reload can create a new
guest at the next interaction; server IP/project counters must survive it.
No timer refreshes credentials. `ensure()` reuses a valid identity until its
remaining lifetime reaches 30 seconds. Concurrent calls share one issuance.

States: idle, pending, ready, error, disposed. Observe with `subscribe(callback)`.
`invalidate()` clears a rejected guest without replaying its product operation.
`authenticated()` clears guest credentials after verified account sign-in;
`dispose()` aborts pending work and prevents late responses restoring identity.

Errors are `GuestSessionError` with `code`, `status`, `category`, `retryable`,
`rid`, and nullable `retryAfter` seconds. Server error fields are retained from
the exact shared envelope. Network failures use `guest_unavailable`; malformed
responses use `guest_response_invalid`; superseded requests use
`guest_session_changed`. Consumers display failures without granting admission.
