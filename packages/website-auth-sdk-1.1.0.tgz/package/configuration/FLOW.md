# Website authentication flow

Version 1 centralizes authentication navigation and observable
state. Sites own their markup, copy, styles and existing skeletons. The controller
owns session checks, action concurrency, the 600 ms submission feedback minimum,
OAuth selection, and authentication navigation. Cookie handling remains in the
same-origin Pages facade.

```js
import { createWebsiteAuthFlow, attachWebsiteAuthFlow } from 'website-auth-sdk';
const auth = createWebsiteAuthFlow({
  authBaseUrl: '/api/auth',
  storageKey: 'product.auth.v1',
  requestIdPrefix: 'product-auth',
  getOAuthCallbackUrl: () => `${location.origin}/auth/callback/`,
  oauthSuccessUrl: '/dashboard/',
  oauthFailureUrl: '/?auth=sign-in',
  signedOutUrl: '/',
  isProtectedRoute: url => url.pathname.startsWith('/dashboard'),
});
const detach = attachWebsiteAuthFlow(auth);
const unsubscribe = auth.subscribe(state => {
  // Render the existing UI from state; never grant access from metadata.
  render({ ...state });
});
void auth.start().catch(showError);
// Explicit UI actions:
// auth.login(email, password), auth.signup(input), auth.oauth('google'), auth.logout()
// Component cleanup: unsubscribe(); document owner cleanup: detach(); auth.dispose();
```

`subscribe` immediately emits a read-only snapshot and returns an unsubscribe
function. It supports Svelte store subscriptions. `canRenderProtected` is false
before verification and on failure. Network failure produces `unavailable`, not
an invented anonymous session. Public metadata is never authorization.

`busy` and `action` control all competing authentication inputs. Submission
requests start immediately; feedback lasts at least 600 ms. Session checks and
OAuth callbacks have no minimum delay. Native Google readiness is read during
the click. Script preloading is silent; dismissal never starts a redirect.

The callback route must invoke `start` or `completeOAuthRedirectCallback`. Root
callbacks run only when an OAuth response is present. Configure the existing
routes and locale paths for each product. Success and signed-out navigation
must remain same-origin. No transport method is exposed from the public flow.

`runAuthenticated(operation)` validates the session and executes the operation
once. It never retries business mutations. Logout hides protected UI immediately,
invalidates late results, waits for an earlier auth response before clearing
server cookies, and reports failure honestly. A failed logout does not silently
restore the session in the same document.

Recovery uses the explicit configuration in [RECOVERY.md](RECOVERY.md).
`verifyPasswordRecovery` and `getPasswordRecoveryContext` produce a separate
`recovery` state, never an authenticated business session. Completion remains
visible so an unconfirmed session revocation can be reported. Recovery links
are consumed only by an explicit user action.

## Errors

Transport errors retain `WebsiteAuthError` fields: `name`, `message`, `code`,
`status`, `retryable`, `action`, `field`, and nullable `rid`. Local flow codes:
`auth_flow_busy` and `auth_flow_disposed` have status 0;
`auth_session_required` and `auth_session_changed` have status 401.
`auth_recovery_required` has status 403. Invalid configuration throws TypeError.
Worker codes retain their original values; no translation to generic success.

```json
{"name":"WebsiteAuthError","message":"An authenticated session is required.","code":"auth_session_required","status":401,"retryable":false,"action":null,"field":null,"rid":null}
```

## Remote verification

The immutable package includes `tests/`. Dictum test website executes each test
entry point with Node in its Cloudflare Pages Full build. Direct entry execution
avoids Node test discovery excluding `node_modules`. No local test execution or
browser simulation runner is required.

Version 1 requires the shared flow. The cookie transport client is private.
The universal Pages command validates consumer integration in Fast and Full;
Full also executes packaged authentication tests.

## Existing account operations

`updateAccountProfile`, `updateAccountPassword`, `ensureAppAccess`, and
`requestAccountPasswordRecovery` expose the existing named contracts without a
public generic transport. Profile updates retain the verified session. Business
operations cannot execute on a configured recovery route. Dictum's existing
Worker-allowlisted recovery destination remains `/dashboard?mode=recovery`;
`isRecoveryRoute` isolates its visual state until the central recovery policy
and email template are migrated together. This compatibility does not enable
new recovery destinations or claim that legacy cookies are separately scoped.

`isAuthRoute` redirects already verified users through the configured success route.
`getCaptchaToken(signal)` keeps product challenge preparation inside SDK pending state.
Repeated callback completion shares one exchange. Hidden navigation remains gated
until visibility returns when `gateWhenHidden` is enabled.

## Website-specific owner access

Pages authentication accepts optional `allowedEmail`. When set, a session grant
is checked through the private authentication binding before any session cookie
is issued. Existing sessions are checked on verification and before account
mutations. Only an exact email match with a confirmed email timestamp passes.
Omitting this option preserves product website access policies.

Protect business Functions with `createPagesAccessGuard` from
`website-auth-sdk/cloudflare-pages`, using the same app slug, cookie names,
binding and `allowedEmail` as the authentication handler. Call it before any
protected read or write; a Response denies access, while `null` permits the
operation. The guard ignores browser Authorization headers and reads only the
configured HttpOnly access cookie. Do not cache an authorization decision.

```js
const requireAccess = createPagesAccessGuard({
  appSlug: 'example-product',
  allowedEmail: 'owner@example.com',
});
export async function onRequest(context) {
  const denied = await requireAccess(context);
  if (denied) return denied;
  return context.next();
}
```

New failures use the existing JSON envelope: `ok: false`, string `rid`, and
`error` containing string `code`, `message`, `category`, boolean `retryable`.
`website_access_denied` maps to 403, category `authorization`, retryable false,
and clears session cookies. `auth_verification_failed` maps to 502, category
`internal`, retryable true. Missing sessions return existing `auth_required`
with 401, category `authentication`, retryable false. Invalid configuration
throws TypeError before serving requests.

```json
{"ok":false,"rid":"website-access-test","error":{"code":"website_access_denied","message":"This account is not authorized to access this website.","category":"authorization","retryable":false}}
```

`tests/website-access.test.js` runs with the packaged SDK tests in the Dictum
remote Full build. Consumer middleware must cover every protected Function;
login endpoints and their public UI must remain reachable before sign-in.

`createPagesWebsiteGuard` wraps the same identity check around the entire site.
Configure a `signInPath` and an explicit `publicPaths` array containing only
login documents and their assets. The root path cannot be public. The middleware
also leaves `/api/auth/*` reachable; its handler must use the same `allowedEmail`.
All other paths, including static JSON, bundles and business APIs, require the
verified owner. Anonymous or denied HTML navigations redirect with 303 to the
sign-in path; API requests retain the documented 401/403 JSON failure. Dependency
failures remain 5xx, never an authorization success. Protected responses are
private and no-store; WebSocket upgrades retain their original response.
Invalid route configuration throws TypeError.
