export type GuestSession = Readonly<{projectId:string;subjectId:string;token:string;expiresAt:number}>;
export class GuestSessionError extends Error {
  code:string;status:number;category:string;retryable:boolean;rid:string|null;retryAfter:number|null;
}
export type GuestState = Readonly<{phase:'idle'|'pending'|'ready'|'error'|'disposed';session:GuestSession|null;error:GuestSessionError|null}>;
export function createGuestSession(config:{endpoint:string;projectId:string;fetch?:typeof fetch;now?:()=>number;timeoutMs?:number}):Readonly<{
  readonly state:GuestState;
  subscribe(listener:(state:GuestState)=>void):()=>void;
  ensure():Promise<GuestSession>;
  invalidate():void;
  authenticated():void;
  dispose():void;
}>;
