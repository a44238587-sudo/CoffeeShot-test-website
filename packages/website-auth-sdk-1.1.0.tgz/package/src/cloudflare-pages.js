import { RECOVERY_ROUTES } from "./recovery.js";
import { handleRecoveryPages } from "./recovery-pages.js";
const AUTH_ROUTES = new Set([
  "token/google/start",
  "token/google/exchange",
  "token/google/id-token",
  "token/apple/start",
  "token/apple/exchange",
  "token/apple/id-token",
  "token/github/start",
  "token/github/exchange",
  "token/password/login",
  "token/email/confirm",
  "token/password/signup",
  "token/password/recover",
  "token/refresh",
  "account/logout",
  "account/profile",
  "account/email",
  "account/password",
  "verify",
  "access/ensure",
]);

const COOKIE_SESSION_LOGOUT_ROUTE = "session/logout";
const COOKIE_AUTH_ROUTES = new Set([...AUTH_ROUTES, ...RECOVERY_ROUTES, COOKIE_SESSION_LOGOUT_ROUTE, "session/oauth/store", "session/oauth/consume"]);
const SESSION_GRANT_ROUTES = new Set([
  "token/google/exchange",
  "token/apple/exchange",
  "token/github/exchange",
  "token/google/id-token",
  "token/apple/id-token",
  "token/password/login",
  "token/email/confirm",
  "token/refresh",
]);
const AUTHENTICATED_ROUTES = new Set([
  "account/logout",
  "account/profile",
  "account/email",
  "account/password",
  "verify",
  "access/ensure",
]);

const MAX_AUTH_REQUEST_BYTES = 65_536;
const MAX_AUTH_RESPONSE_BYTES = 1_048_576;
const MAX_SESSION_LIFETIME_SECONDS = 31_536_000;
const DEFAULT_REFRESH_COOKIE_MAX_AGE_SECONDS = 31_536_000;
const DEFAULT_INTERNAL_ORIGIN = "https://auth-supabase-app.internal";
const COOKIE_NAME_PATTERN = /^(?:__Host-|__Secure-)?[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u;
const PUBLIC_USER_FIELDS = Object.freeze([
  "id",
  "email",
  "phone",
  "role",
  "aud",
  "emailConfirmedAt",
  "phoneConfirmedAt",
  "lastSignInAt",
  "createdAt",
  "updatedAt",
  "displayName",
  "companyName",
  "billingName",
  "billingAddressLine1",
  "billingAddressLine2",
  "billingCity",
  "billingPostalCode",
  "billingCountryCode",
  "billingTaxId",
]);

class RequestBodyTooLarge extends Error {}
class CookieProjectionError extends Error {}

function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function jsonError(
  status,
  code,
  message,
  requestId = null,
  category = "internal",
  retryable = status >= 500
) {
  return Response.json(
    {
      ok: false,
      rid: requestId,
      error: { code, message, category, retryable },
    },
    {
      status,
      headers: {
        "Cache-Control": "no-store",
        ...(requestId ? { "X-Request-Id": requestId } : {}),
      },
    }
  );
}

function cookieErrorPayload(status, code, message, requestId, category, retryable) {
  return {
    ok: false,
    rid: requestId,
    error: {
      code,
      message,
      category,
      retryable: retryable ?? status >= 500,
    },
  };
}

function cookieErrorResponse(headers, status, code, message, requestId, category, retryable) {
  headers.set("Content-Type", "application/json; charset=utf-8");
  appendPrivateSessionHeaders(headers);
  if (requestId) headers.set("X-Request-Id", requestId);
  return new Response(
    JSON.stringify(cookieErrorPayload(status, code, message, requestId, category, retryable)),
    { status, headers }
  );
}

function readRequestId(request) {
  const requestId = request.headers.get("X-Request-Id");
  return requestId &&
    requestId.trim() === requestId &&
    requestId.length <= 128 &&
    /^[A-Za-z0-9][A-Za-z0-9._:-]*$/u.test(requestId)
    ? requestId
    : null;
}

function readAuthRoute(context) {
  const segments = context.params?.path;
  if (!Array.isArray(segments) || !segments.every(segment => typeof segment === "string")) {
    return null;
  }
  const route = segments.join("/");
  return COOKIE_AUTH_ROUTES.has(route) ? route : null;
}

async function readRequestBody(request) {
  const contentLength = request.headers.get("Content-Length");
  if (contentLength && /^\d+$/u.test(contentLength) && Number(contentLength) > MAX_AUTH_REQUEST_BYTES) {
    throw new RequestBodyTooLarge();
  }
  if (!request.body) return undefined;
  const reader = request.body.getReader();
  const chunks = [];
  let length = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > MAX_AUTH_REQUEST_BYTES) {
      await reader.cancel();
      throw new RequestBodyTooLarge();
    }
    chunks.push(value);
  }
  const body = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return body;
}

function validateCookieName(value, field) {
  if (typeof value !== "string" || !COOKIE_NAME_PATTERN.test(value)) {
    throw new TypeError(`${field} must be a safe cookie name.`);
  }
  return value;
}

export function defaultAuthCookieNames(appSlug) {
  if (typeof appSlug !== "string" || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(appSlug)) {
    throw new TypeError("appSlug must use lowercase kebab-case.");
  }
  return Object.freeze({
    accessCookieName: `__Host-${appSlug}-access`,
    refreshCookieName: `__Host-${appSlug}-refresh`,
  });
}

function normalizeOptions(options) {
  if (!options || typeof options !== "object" || Array.isArray(options)) {
    throw new TypeError("Pages auth handler options are required.");
  }
  const { appSlug } = options;
  if (typeof appSlug !== "string" || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(appSlug)) {
    throw new TypeError("appSlug must use lowercase kebab-case.");
  }
  const bindingName = options.bindingName ?? "AUTH_SUPABASE_APP";
  if (typeof bindingName !== "string" || !/^[A-Z][A-Z0-9_]*$/u.test(bindingName)) {
    throw new TypeError("bindingName must be a valid uppercase binding identifier.");
  }
  const internalOrigin = options.internalOrigin ?? DEFAULT_INTERNAL_ORIGIN;
  const parsedOrigin = new URL(internalOrigin);
  if (
    parsedOrigin.protocol !== "https:" ||
    parsedOrigin.username ||
    parsedOrigin.password ||
    parsedOrigin.pathname !== "/" ||
    parsedOrigin.search ||
    parsedOrigin.hash
  ) {
    throw new TypeError("internalOrigin must be an HTTPS origin without credentials or a path.");
  }
  if (Object.hasOwn(options, "sessionMode")) {
    throw new TypeError(
      "sessionMode is not supported. createPagesAuthHandler is cookie-only."
    );
  }
  const allowedEmail = options.allowedEmail;
  if (allowedEmail !== undefined && (typeof allowedEmail !== "string" ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(allowedEmail) || allowedEmail.length > 320)) {
    throw new TypeError("allowedEmail must be an exact email address.");
  }
  const defaults = defaultAuthCookieNames(appSlug);
  const accessCookieName = validateCookieName(
    options.accessCookieName ?? defaults.accessCookieName,
    "accessCookieName"
  );
  const refreshCookieName = validateCookieName(
    options.refreshCookieName ?? defaults.refreshCookieName,
    "refreshCookieName"
  );
  if (accessCookieName === refreshCookieName) {
    throw new TypeError("accessCookieName and refreshCookieName must differ.");
  }
  const refreshCookieMaxAgeSeconds =
    options.refreshCookieMaxAgeSeconds ?? DEFAULT_REFRESH_COOKIE_MAX_AGE_SECONDS;
  if (
    !Number.isSafeInteger(refreshCookieMaxAgeSeconds) ||
    refreshCookieMaxAgeSeconds <= 0 ||
    refreshCookieMaxAgeSeconds > MAX_SESSION_LIFETIME_SECONDS
  ) {
    throw new TypeError("refreshCookieMaxAgeSeconds must be a positive integer of at most 31536000.");
  }
  return Object.freeze({
    appSlug,
    allowedEmail,
    recovery: options.recovery ? Object.freeze({ ...options.recovery }) : null,
    bindingName,
    internalOrigin: parsedOrigin.origin,
    accessCookieName,
    refreshCookieName,
    refreshCookieMaxAgeSeconds,
  });
}

function readCookie(request, name) {
  const cookieHeader = request.headers.get("cookie");
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const separatorIndex = part.indexOf("=");
    if (separatorIndex <= 0) continue;
    if (part.slice(0, separatorIndex).trim() !== name) continue;
    try {
      return decodeURIComponent(part.slice(separatorIndex + 1).trim());
    } catch {
      return null;
    }
  }
  return null;
}

function serializeCookie(name, value, maxAgeSeconds) {
  return [
    `${name}=${encodeURIComponent(value)}`,
    "Path=/",
    `Max-Age=${Math.max(0, Math.floor(maxAgeSeconds))}`,
    "HttpOnly",
    "Secure",
    "SameSite=Lax",
  ].join("; ");
}

function appendPrivateSessionHeaders(headers) {
  headers.set("Cache-Control", "private, no-store");
  headers.set("Pragma", "no-cache");
  headers.set("Expires", "0");
  const vary = headers.get("Vary");
  if (!vary) {
    headers.set("Vary", "Cookie");
  } else if (!vary.split(",").some(value => value.trim().toLowerCase() === "cookie")) {
    headers.set("Vary", `${vary}, Cookie`);
  }
}

function appendSessionCookies(headers, config, accessToken, refreshToken, accessMaxAgeSeconds) {
  headers.append(
    "Set-Cookie",
    serializeCookie(config.accessCookieName, accessToken, accessMaxAgeSeconds)
  );
  headers.append(
    "Set-Cookie",
    serializeCookie(config.refreshCookieName, refreshToken, config.refreshCookieMaxAgeSeconds)
  );
  appendPrivateSessionHeaders(headers);
}

function appendClearedSessionCookies(headers, config) {
  headers.append("Set-Cookie", serializeCookie(config.accessCookieName, "", 0));
  headers.append("Set-Cookie", serializeCookie(config.refreshCookieName, "", 0));
  appendPrivateSessionHeaders(headers);
}

function createBrowserAuthHeaders(requestId) {
  const headers = new Headers({
    "Content-Type": "application/json; charset=utf-8",
  });
  appendPrivateSessionHeaders(headers);
  if (requestId) headers.set("X-Request-Id", requestId);
  return headers;
}

function validToken(value) {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    value.length <= MAX_AUTH_RESPONSE_BYTES &&
    value.trim() === value &&
    !/\s/u.test(value)
  );
}

function containsSecretKeys(value) {
  if (Array.isArray(value)) return value.some(containsSecretKeys);
  if (!isRecord(value)) return false;
  if (Object.hasOwn(value, "accessToken") || Object.hasOwn(value, "refreshToken")) return true;
  return Object.values(value).some(containsSecretKeys);
}

function requirePublicUser(value) {
  if (!isRecord(value)) throw new CookieProjectionError();
  const user = {};
  for (const key of PUBLIC_USER_FIELDS) {
    if (!Object.hasOwn(value, key)) throw new CookieProjectionError();
    const field = value[key];
    if (key === "id") {
      if (typeof field !== "string" || field.length === 0 || field.length > 128) {
        throw new CookieProjectionError();
      }
      user.id = field;
      continue;
    }
    if (field !== null && (typeof field !== "string" || field.length > 1024)) {
      throw new CookieProjectionError();
    }
    user[key] = field;
  }
  return user;
}

function requirePrivateSession(value) {
  if (!isRecord(value)) throw new CookieProjectionError();
  if (
    !validToken(value.accessToken) ||
    !validToken(value.refreshToken) ||
    typeof value.tokenType !== "string" ||
    !/^bearer$/iu.test(value.tokenType) ||
    !Number.isSafeInteger(value.expiresIn) ||
    value.expiresIn <= 0 ||
    value.expiresIn > MAX_SESSION_LIFETIME_SECONDS ||
    !Number.isSafeInteger(value.expiresAt) ||
    value.expiresAt <= 0
  ) {
    throw new CookieProjectionError();
  }
  return {
    accessToken: value.accessToken,
    refreshToken: value.refreshToken,
    publicSession: {
      authenticated: true,
      tokenType: "bearer",
      expiresIn: value.expiresIn,
      expiresAt: value.expiresAt,
    },
  };
}

function projectGrantedSession(payload) {
  const privateSession = requirePrivateSession(
    isRecord(payload) && "session" in payload ? payload.session : payload
  );
  return {
    accessToken: privateSession.accessToken,
    refreshToken: privateSession.refreshToken,
    publicSession: privateSession.publicSession,
  };
}

function projectCookieSuccess(route, payload, requestId) {
  if (!isRecord(payload) || payload.ok !== true) throw new CookieProjectionError();
  if (requestId && payload.rid != null && payload.rid !== requestId) {
    throw new CookieProjectionError();
  }

  if (SESSION_GRANT_ROUTES.has(route)) {
    const granted = projectGrantedSession(payload);
    if (route === "token/email/confirm" && (payload.grantType !== "email" || !payload.user?.emailConfirmedAt)) throw new CookieProjectionError();
    const publicPayload = {
      ...payload,
      session: granted.publicSession,
      user: requirePublicUser(payload.user),
    };
    delete publicPayload.accessToken;
    delete publicPayload.refreshToken;
    return {
      accessToken: granted.accessToken,
      refreshToken: granted.refreshToken,
      publicPayload,
    };
  }

  if (route === "token/password/signup") {
    if (typeof payload.confirmationRequired !== "boolean") throw new CookieProjectionError();
    if (payload.confirmationRequired !== (payload.session === null)) {
      throw new CookieProjectionError();
    }
    const user = requirePublicUser(payload.user);
    if (payload.session === null) {
      return {
        accessToken: null,
        refreshToken: null,
        publicPayload: { ...payload, session: null, user },
      };
    }
    const granted = projectGrantedSession(payload);
    return {
      accessToken: granted.accessToken,
      refreshToken: granted.refreshToken,
      publicPayload: { ...payload, session: granted.publicSession, user },
    };
  }

  const publicPayload = { ...payload };
  if (Object.hasOwn(publicPayload, "user")) {
    publicPayload.user = requirePublicUser(publicPayload.user);
  }
  if (isRecord(publicPayload.session)) {
    if (
      Object.hasOwn(publicPayload.session, "accessToken") ||
      Object.hasOwn(publicPayload.session, "refreshToken")
    ) {
      throw new CookieProjectionError();
    }
  }
  delete publicPayload.accessToken;
  delete publicPayload.refreshToken;
  return {
    accessToken: null,
    refreshToken: null,
    publicPayload,
  };
}

async function readUpstreamJson(response) {
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.toLowerCase().includes("application/json")) {
    throw new CookieProjectionError();
  }
  const contentLength = response.headers.get("content-length");
  if (
    contentLength &&
    /^\d+$/u.test(contentLength) &&
    Number(contentLength) > MAX_AUTH_RESPONSE_BYTES
  ) {
    throw new CookieProjectionError();
  }
  const text = await response.text();
  if (new TextEncoder().encode(text).byteLength > MAX_AUTH_RESPONSE_BYTES) {
    throw new CookieProjectionError();
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new CookieProjectionError();
  }
}

function shouldClearCookiesOnFailure(route, status) {
  return route === "token/refresh" || route === "account/logout" || status === 401;
}

async function confirmationFailure(upstream, requestId) {
  if (upstream.status !== 401) return null;
  let payload;
  try { payload = await readUpstreamJson(upstream); } catch { return null; }
  const error = payload?.error;
  if (!isRecord(payload) || Object.keys(payload).sort().join(',') !== 'error,ok,rid' ||
      payload.ok !== false || payload.rid !== requestId || !isRecord(error) ||
      Object.keys(error).sort().join(',') !== 'category,code,message,retryable' ||
      error.code !== 'AUTH_CORE.CONFIRMATION_EXPIRED' || error.category !== 'authentication' ||
      error.retryable !== false || typeof error.message !== 'string') return null;
  // Reconstruct controlled copy; never relay provider/server diagnostics.
  return {
    code: 'AUTH_CORE.CONFIRMATION_EXPIRED',
    message: 'The confirmation token is invalid or has expired. Request a new confirmation email.',
    category: 'authentication', retryable: false,
  };
}

async function projectCookieResponse(config, { route, requestId, upstream, service, signal }) {
  const headers = createBrowserAuthHeaders(requestId);
  if (!upstream.ok) {
    if (shouldClearCookiesOnFailure(route, upstream.status)) {
      appendClearedSessionCookies(headers, config);
    }
    const status =
      upstream.status >= 400 && upstream.status <= 599 ? upstream.status : 502;
    if (route === 'token/email/confirm') {
      const failure = await confirmationFailure(upstream, requestId);
      if (failure) return cookieErrorResponse(headers, status, failure.code, failure.message, requestId, failure.category, failure.retryable);
    }
    return cookieErrorResponse(
      headers,
      status,
      "auth_request_failed",
      "The authentication request failed.",
      requestId,
      status >= 500 ? "internal" : "request",
      status >= 500
    );
  }

  let payload;
  try {
    payload = await readUpstreamJson(upstream);
  } catch {
    if (route === "token/refresh") appendClearedSessionCookies(headers, config);
    return cookieErrorResponse(
      headers,
      502,
      "auth_response_invalid",
      "The authentication service returned an invalid response.",
      requestId
    );
  }

  let projected;
  try {
    projected = projectCookieSuccess(route, payload, requestId);
    if (containsSecretKeys(projected.publicPayload)) throw new CookieProjectionError();
  } catch {
    if (route === "token/refresh") appendClearedSessionCookies(headers, config);
    return cookieErrorResponse(
      headers,
      502,
      "auth_response_invalid",
      "The authentication service returned an unsafe or invalid response.",
      requestId
    );
  }

  if (config.allowedEmail && projected.accessToken) {
    const denied = await verifyAllowedIdentity(config, service, projected.accessToken, requestId, signal);
    if (denied) return denied;
  }
  if (config.allowedEmail && route === "verify" && payload.valid === true &&
      !isAllowedIdentity(config, payload.user)) return accessDenied(config, requestId);
  if (projected.accessToken && projected.refreshToken) {
    appendSessionCookies(
      headers,
      config,
      projected.accessToken,
      projected.refreshToken,
      projected.publicPayload.session.expiresIn
    );
  }
  if (route === "verify" && projected.publicPayload.valid === false) {
    appendClearedSessionCookies(headers, config);
  }
  if (route === "account/logout") {
    appendClearedSessionCookies(headers, config);
  }
  headers.set("Content-Type", "application/json; charset=utf-8");
  return new Response(JSON.stringify(projected.publicPayload), {
    status: upstream.status,
    headers,
  });
}

function createCookieLogoutResponse(config, requestId) {
  const headers = createBrowserAuthHeaders(requestId);
  appendClearedSessionCookies(headers, config);
  return new Response(JSON.stringify({ ok: true, ...(requestId ? { rid: requestId } : {}) }), {
    status: 200,
    headers,
  });
}

function buildCookieServiceRequest(config, { request, route, requestId, body }) {
  const headers = new Headers({
    "content-type": "application/json",
    "x-request-id": requestId,
  });
  let forwardedBody = body;

  if (route === "token/refresh") {
    const refreshToken = readCookie(request, config.refreshCookieName);
    forwardedBody = new TextEncoder().encode(JSON.stringify(refreshToken ? { refreshToken } : {}));
  } else if (AUTHENTICATED_ROUTES.has(route)) {
    const accessToken = readCookie(request, config.accessCookieName);
    if (accessToken) headers.set("authorization", `Bearer ${accessToken}`);
  }

  if (config.allowedEmail && route === "verify") {
    forwardedBody = new TextEncoder().encode(JSON.stringify({ includeUser: true }));
  }
  return {
    headers,
    body: forwardedBody,
  };
}

export const WEBSITE_AUTH_ROUTES = Object.freeze([...COOKIE_AUTH_ROUTES]);
export const COOKIE_WEBSITE_AUTH_ROUTES = WEBSITE_AUTH_ROUTES;
export { COOKIE_SESSION_LOGOUT_ROUTE };

export function createPagesAuthHandler(options) {
  const config = normalizeOptions(options);
  return async function onRequest(context) {
    if (context.request.method !== "POST") {
      return new Response("Method Not Allowed", {
        status: 405,
        headers: { Allow: "POST", "Cache-Control": "no-store" },
      });
    }
    const url = new URL(context.request.url);
    const route = readAuthRoute(context);
    if (!route || url.search !== "") {
      return new Response("Not Found", {
        status: 404,
        headers: { "Cache-Control": "no-store" },
      });
    }
    const requestId = readRequestId(context.request);
    if (!requestId) {
      return jsonError(500, "request_id_required", "A valid X-Request-Id header is required.");
    }
    if (RECOVERY_ROUTES.includes(route)) return handleRecoveryPages(config, context, route, requestId, { jsonError, readRequestBody, readCookie, serializeCookie, readUpstreamJson });
    if (route === "session/oauth/store" || route === "session/oauth/consume") {
      if (context.request.headers.get("origin") !== url.origin) return jsonError(403,"origin_required","Same-origin request required.",requestId);
      const cookieName = `__Host-${config.appSlug}-oauth`;
      const headers = new Headers({"content-type":"application/json","cache-control":"no-store","x-request-id":requestId});
      if (route === "session/oauth/consume") {
        headers.append("set-cookie", `${cookieName}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`);
        let pending = null;
        try { const value = readCookie(context.request,cookieName); if(value) pending=JSON.parse(decodeURIComponent(value)); } catch { pending=null; }
        return new Response(JSON.stringify({ok:true,pending}),{headers});
      }
      try {
        const value = JSON.parse(new TextDecoder().decode(await readRequestBody(context.request)));
        if (!value || Object.keys(value).sort().join(",")!=="createdAt,provider,redirectTo,verifier"
          || !["google","apple","github"].includes(value.provider)
          || typeof value.verifier!=="string" || !/^[A-Za-z0-9._~-]{43,128}$/.test(value.verifier)
          || typeof value.redirectTo!=="string" || value.redirectTo.length>2048 || new URL(value.redirectTo).origin!==url.origin
          || typeof value.createdAt!=="number" || !Number.isFinite(value.createdAt)) return jsonError(400,"oauth_state_invalid","Invalid OAuth state.",requestId);
        value.createdAt=Date.now();
        headers.append("set-cookie", `${cookieName}=${encodeURIComponent(JSON.stringify(value))}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=300`);
        return new Response(JSON.stringify({ok:true}),{headers});
      } catch { return jsonError(400,"oauth_state_invalid","Invalid OAuth state.",requestId); }
    }
    if (route === COOKIE_SESSION_LOGOUT_ROUTE) {
      return createCookieLogoutResponse(config, requestId);
    }
    if (route === "token/refresh" && !readCookie(context.request, config.refreshCookieName)) {
      return jsonError(401, "auth_required", "Sign in to continue.", requestId);
    }
    const service = context.env?.[config.bindingName];
    if (!service || typeof service.fetch !== "function") {
      return jsonError(
        500,
        "service_binding_unavailable",
        "The authentication service is unavailable.",
        requestId
      );
    }
    try {
      if (config.allowedEmail && AUTHENTICATED_ROUTES.has(route) && route !== "verify" && route !== "account/logout") {
        const denied = await verifyAllowedIdentity(config, service,
          readCookie(context.request, config.accessCookieName), requestId, context.request.signal);
        if (denied) return denied;
      }
      const body = await readRequestBody(context.request);
      const cookieRequest = buildCookieServiceRequest(config, {
        request: context.request,
        route,
        requestId,
        body,
      });
      const upstream = await service.fetch(
        new Request(`${config.internalOrigin}/${config.appSlug}/${route}`, {
          method: "POST",
          headers: cookieRequest.headers,
          body: cookieRequest.body,
          signal: context.request.signal,
        })
      );
      return await projectCookieResponse(config, { route, requestId, upstream, service, signal: context.request.signal });
    } catch (error) {
      if (error instanceof RequestBodyTooLarge) {
        return jsonError(
          413,
          "AUTH_APP.BODY_TOO_LARGE",
          "The authentication request body is too large.",
          requestId,
          "validation",
          false
        );
      }
      console.error("Authentication service binding failed.", {
        requestId,
        route,
        error,
      });
      return jsonError(
        502,
        "service_binding_failed",
        "The authentication service is unavailable.",
        requestId
      );
    }
  };
}

export function createCookiePagesAuthHandler(options) {
  return createPagesAuthHandler(options);
}

/** Only identity returned by the authentication service establishes access. */
function isAllowedIdentity(config, user) {
  return isRecord(user) && user.email === config.allowedEmail &&
    typeof user.emailConfirmedAt === "string" && Number.isFinite(Date.parse(user.emailConfirmedAt));
}

function accessDenied(config, requestId) {
  const headers = createBrowserAuthHeaders(requestId);
  appendClearedSessionCookies(headers, config);
  return cookieErrorResponse(headers, 403, "website_access_denied",
    "This account is not authorized to access this website.", requestId, "authorization", false);
}

async function verifyAllowedIdentity(config, service, token, requestId, signal) {
  if (!token) return jsonError(401, "auth_required", "Sign in to continue.", requestId, "authentication", false);
  const upstream = await service.fetch(new Request(`${config.internalOrigin}/${config.appSlug}/verify`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-request-id": requestId, "authorization": `Bearer ${token}` },
    body: JSON.stringify({ includeUser: true }), signal,
  }));
  if (!upstream.ok) {
    await upstream.body?.cancel();
    return upstream.status === 401 || upstream.status === 403
      ? accessDenied(config, requestId)
      : jsonError(502, "auth_verification_failed", "The authentication service is unavailable.", requestId);
  }
  const payload = await readUpstreamJson(upstream);
  if (!isRecord(payload) || payload.ok !== true || payload.rid !== requestId || typeof payload.valid !== "boolean") {
    return jsonError(502, "auth_response_invalid", "The authentication service returned an invalid response.", requestId);
  }
  return payload.valid === true && isAllowedIdentity(config, payload.user) ? null : accessDenied(config, requestId);
}

/** Check the HttpOnly session before a protected Pages operation; null permits it. */
export function createPagesAccessGuard(options) {
  const config = normalizeOptions(options);
  if (!config.allowedEmail) throw new TypeError("An access guard requires allowedEmail.");
  return async function requireWebsiteAccess({ request, env }) {
    const requestId = readRequestId(request) ?? `website-access-${crypto.randomUUID()}`;
    const service = env?.[config.bindingName];
    if (!service || typeof service.fetch !== "function") {
      return jsonError(500, "service_binding_unavailable", "The authentication service is unavailable.", requestId);
    }
    try {
      return await verifyAllowedIdentity(config, service, readCookie(request, config.accessCookieName), requestId, request.signal);
    } catch {
      return jsonError(502, "auth_verification_failed", "The authentication service is unavailable.", requestId);
    }
  };
}

/** Gate the entire website, leaving only explicitly listed login assets public. */
export function createPagesWebsiteGuard(options) {
  const requireAccess = createPagesAccessGuard(options);
  const { signInPath, publicPaths } = options;
  const isPath = value => typeof value === 'string' && /^\/(?!\/)[^?#\\]*$/u.test(value);
  if (!isPath(signInPath) || !Array.isArray(publicPaths) || !publicPaths.every(isPath) ||
      !publicPaths.includes(signInPath) || publicPaths.includes('/')) {
    throw new TypeError('A signInPath and exact publicPaths without the protected root are required.');
  }
  const publicSet = new Set(publicPaths);
  return async function onRequest(context) {
    const url = new URL(context.request.url);
    if (url.pathname.startsWith('/api/auth/') || publicSet.has(url.pathname)) return context.next();
    const denied = await requireAccess(context);
    if (denied) {
      const navigation = ['GET', 'HEAD'].includes(context.request.method) &&
        context.request.headers.get('accept')?.includes('text/html');
      if (navigation && (denied.status === 401 || denied.status === 403)) {
        const headers = new Headers(denied.headers);
        headers.delete('content-type');
        headers.set('location', signInPath);
        await denied.body?.cancel();
        return new Response(null, { status: 303, headers });
      }
      return denied;
    }
    const response = await context.next();
    if (response.status === 101) return response;
    const headers = new Headers(response.headers);
    appendPrivateSessionHeaders(headers);
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  };
}
