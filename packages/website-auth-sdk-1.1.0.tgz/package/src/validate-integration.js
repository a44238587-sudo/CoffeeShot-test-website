import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';

const methods = new Set([
  'state', 'subscribe', 'start', 'verify', 'routeChanged', 'pageShown', 'visibilityChanged',
  'login', 'signup', 'oauth', 'completeOAuthRedirectCallback', 'logout',
  'confirmEmail', 'requestPasswordRecovery', 'verifyPasswordRecovery',
  'getPasswordRecoveryContext', 'completePasswordRecovery', 'clearPasswordRecovery',
  'runAuthenticated', 'dispose', 'invalidateSession', 'storageChanged',
  'requestAccountPasswordRecovery', 'updateAccountProfile', 'updateAccountPassword', 'ensureAppAccess',
]);

/** Validate browser integration against the flow's public API before deployment. */
export function validateWebsiteAuthIntegration(root) {
  const errors = [];
  const sources = [];
  function visit(directory) {
    for (const entry of readdirSync(directory)) {
      if (['node_modules', 'dist', '.git'].includes(entry)) continue;
      const path = join(directory, entry);
      if (statSync(path).isDirectory()) visit(path);
      else if (/\.(?:js|ts|svelte|astro)$/.test(entry) && !/\.(?:test|spec)\./.test(entry)) {
        sources.push({ path, source: readFileSync(path, 'utf8') });
      }
    }
  }
  visit(join(root, 'src'));
  for (const { path, source } of sources) {
    for (const match of source.matchAll(/(?<![\w$.'"/-])(?:websiteAuth|auth)\.(\w+)/g)) {
      if (!methods.has(match[1])) errors.push(`${relative(root, path)}: unsupported flow member ${match[1]}`);
    }
    if (/\bcreateCookieWebsiteAuth\b|website-auth-sdk\/src\//.test(source)) {
      errors.push(`${relative(root, path)}: private cookie client import`);
    }
  }
  const all = sources.map(entry => entry.source).join('\n');
  for (const required of ['createWebsiteAuthFlow', 'attachWebsiteAuthFlow', '.subscribe(', '.start(']) {
    if (!all.includes(required)) errors.push(`Missing authentication flow integration: ${required}`);
  }
  if (errors.length) throw new Error(errors.join('\n'));
  return { files: sources.length };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const result = validateWebsiteAuthIntegration(process.cwd());
  console.log(`Validated authentication flow in ${result.files} browser source files.`);
}
