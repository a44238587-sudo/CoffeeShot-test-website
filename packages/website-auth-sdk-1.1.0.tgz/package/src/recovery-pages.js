import { RECOVERY_ERRORS, validRecoveryUrl } from './recovery.js';

export async function handleRecoveryPages(config, context, route, requestId, helpers) {
  const { jsonError, readRequestBody, readCookie, serializeCookie, readUpstreamJson } = helpers;
  const fail = (code, fallbackStatus = 502) => {
    const [status, category, message] = RECOVERY_ERRORS[code] ?? [fallbackStatus, 'dependency', 'The recovery service could not complete the request.'];
    return jsonError(status, code, message, requestId, category, false);
  };
  const policy = config.recovery;
  if (!policy?.enabled || !Array.isArray(policy.returnUrls) || !policy.returnUrls.length || !policy.returnUrls.every(validRecoveryUrl) ||
      !Number.isSafeInteger(policy.contextMaxAgeSeconds) || policy.contextMaxAgeSeconds < 1 || policy.contextMaxAgeSeconds > 3600) return fail('AUTH_APP.RECOVERY_NOT_CONFIGURED');
  const origin = new URL(context.request.url).origin;
  if (!policy.returnUrls.some(url => new URL(url).origin === origin) || context.request.headers.get('origin') !== origin ||
      !/^application\/json(?:;|$)/iu.test(context.request.headers.get('content-type') ?? '') ||
      ['cross-site', 'same-site'].includes(context.request.headers.get('sec-fetch-site'))) return jsonError(403, 'AUTH_APP.RECOVERY_CSRF', 'Same-origin recovery request required.', requestId, 'authentication', false);
  const cookieName = policy.cookieName ?? `__Host-${config.appSlug}-recovery`;
  if (!/^__Host-[A-Za-z0-9._-]+$/u.test(cookieName) || [config.accessCookieName, config.refreshCookieName].includes(cookieName)) return fail('AUTH_APP.RECOVERY_NOT_CONFIGURED');
  const response = (value, cookie) => {
    const headers = { 'content-type': 'application/json', 'cache-control': 'private, no-store', 'pragma': 'no-cache', 'referrer-policy': 'no-referrer', 'x-request-id': requestId, ...(cookie ? { 'set-cookie': cookie } : {}) };
    return Response.json({ ok: true, rid: requestId, ...value }, { headers });
  };
  const clear = () => serializeCookie(cookieName, '', 0);
  let body, bytes;
  try { body = JSON.parse(new TextDecoder().decode(bytes = await readRequestBody(context.request))); }
  catch (error) { if (error?.constructor?.name === 'RequestBodyTooLarge') return jsonError(413, 'AUTH_APP.BODY_TOO_LARGE', 'The authentication request body is too large.', requestId, 'validation', false); return jsonError(400, 'AUTH_APP.INVALID_BODY', 'The authentication request body is invalid.', requestId, 'validation', false); }
  const allowed = route === 'token/password/recover' ? ['email', 'redirectTo', 'captchaToken'] : route.endsWith('/verify') ? ['tokenHash'] : route.endsWith('/complete') ? ['password'] : [];
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(key => !allowed.includes(key))) return fail('AUTH_APP.INVALID_BODY', 400);
  if (route === 'session/recovery/clear') return response({ cleared: true }, clear());
  if (route === 'token/password/recover' && !policy.returnUrls.includes(body.redirectTo)) return fail('AUTH_APP.RECOVERY_REDIRECT_FORBIDDEN');
  const headers = new Headers({ 'content-type': 'application/json', 'x-request-id': requestId });
  const protectedRoute = route.endsWith('/context') || route.endsWith('/complete');
  if (protectedRoute) {
    const token = readCookie(context.request, cookieName);
    if (!token || !/^[a-f0-9]{64}$/u.test(token)) return fail('AUTH_CORE.RECOVERY_EXPIRED');
    headers.set('authorization', `Bearer ${token}`);
  }
  const service = context.env?.[config.bindingName];
  if (!service?.fetch) return fail('AUTH_APP.RECOVERY_NOT_CONFIGURED');
  const invalid = () => fail(route.endsWith('/verify') || route.endsWith('/complete') ? 'AUTH_APP.RECOVERY_UNCERTAIN' : 'AUTH_APP.DOWNSTREAM_FAILED');
  try {
    const upstream = await service.fetch(new Request(`${config.internalOrigin}/${config.appSlug}/${route}`, {
      method: 'POST', headers, body: bytes, signal: context.request.signal
    }));
    const value = await readUpstreamJson(upstream);
    if (value?.rid !== requestId) return invalid();
    if (!upstream.ok) {
      const known = RECOVERY_ERRORS[value?.error?.code];
      if (value?.ok === false && known && known[0] === upstream.status && Object.keys(value).sort().join(',') === 'error,ok,rid' && value.error && Object.keys(value.error).sort().join(',') === 'category,code,message,retryable' && typeof value.error.retryable === 'boolean' && typeof value.error.message === 'string') return fail(value.error.code);
      return invalid();
    }
    if (value?.ok !== true) return invalid();
    if (route === 'token/password/recover') {
      if (Object.keys(value).sort().join(',') !== 'ok,recoveryRequested,rid' || value.recoveryRequested !== true) return invalid();
      return response({ recoveryRequested: true });
    }
    if (route.endsWith('/verify')) {
      if (Object.keys(value).sort().join(',') !== 'email,expiresAt,grantType,ok,recoveryToken,rid' || value.grantType !== 'recovery' ||
          !/^[a-f0-9]{64}$/u.test(value.recoveryToken) || !Number.isSafeInteger(value.expiresAt) || value.expiresAt <= Date.now() ||
          (value.email !== null && typeof value.email !== 'string')) return invalid();
      const seconds = Math.min(policy.contextMaxAgeSeconds, Math.floor((value.expiresAt - Date.now()) / 1000));
      return response({ authorized: true, expiresAt: Math.min(value.expiresAt, Date.now() + seconds * 1000), email: value.email }, serializeCookie(cookieName, value.recoveryToken, seconds));
    }
    if (value.passwordUpdated === true && value.authorized === false && typeof value.sessionsRevoked === 'boolean' && Object.keys(value).sort().join(',') === 'authorized,ok,passwordUpdated,rid,sessionsRevoked') {
      return response({ authorized: false, passwordUpdated: true, sessionsRevoked: value.sessionsRevoked }, clear());
    }
    if (route.endsWith('/context') && value.authorized === true && Number.isSafeInteger(value.expiresAt) && value.expiresAt > Date.now() &&
        (value.email === null || typeof value.email === 'string') && Object.keys(value).sort().join(',') === 'authorized,email,expiresAt,ok,rid') {
      return response({ authorized: true, expiresAt: value.expiresAt, email: value.email });
    }
    return invalid();
  } catch {
    // Never log raw exceptions, tokens, passwords, request bodies or URLs.
    return fail(route.endsWith('/verify') || route.endsWith('/complete') ? 'AUTH_APP.RECOVERY_UNCERTAIN' : 'AUTH_APP.DOWNSTREAM_FAILED');
  }
}
