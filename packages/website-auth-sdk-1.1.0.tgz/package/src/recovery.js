export const RECOVERY_ROUTES = Object.freeze([
  'token/password/recover', 'token/password/recovery/verify',
  'token/password/recovery/context', 'token/password/recovery/complete', 'session/recovery/clear'
]);
export const RECOVERY_ERRORS = Object.freeze({
  'AUTH_CORE.RECOVERY_EXPIRED': [401, 'authentication', 'The recovery link or context is invalid, expired or already used. Request a new link.'],
  'AUTH_CORE.RECOVERY_UNCERTAIN': [409, 'conflict', 'The recovery result is uncertain. Do not resubmit the link or password. Check recovery status or request a new link.'],
  'AUTH_APP.RECOVERY_UNCERTAIN': [409, 'conflict', 'The recovery result is uncertain. Do not resubmit the link or password. Check recovery status or request a new link.'],
  'AUTH_APP.RECOVERY_NOT_CONFIGURED': [503, 'configuration', 'Password recovery is not configured for this website.'],
  'AUTH_CORE.RECOVERY_NOT_CONFIGURED': [503, 'configuration', 'Password recovery is not configured for this website.'],
  'AUTH_APP.RECOVERY_REDIRECT_FORBIDDEN': [422, 'validation', 'The password recovery destination is not allowed.'],
  'AUTH_CORE.WEAK_PASSWORD': [422, 'validation', 'Choose a password that meets the password security requirements.'],
  'AUTH_CORE.REAUTHENTICATION_REQUIRED': [401, 'authentication', 'Password verification is required by the identity provider. Request a new recovery link.'],
  'AUTH_CORE.AUTH_CONFLICT': [409, 'conflict', 'The new password could not be accepted. Choose a different password.'],
  'AUTH_CORE.CAPTCHA_FAILED': [422, 'validation', 'The CAPTCHA challenge could not be verified.'],
  'AUTH_CORE.SUPABASE_RATE_LIMITED': [503, 'quota', 'Too many requests. Please try again later.'],
  'AUTH_CORE.SUPABASE_FAILED': [502, 'dependency', 'The email or authentication service could not complete the request. Please try again later.'],
  'AUTH_CORE.SUPABASE_TIMEOUT': [504, 'dependency', 'The authentication service timed out.'],
  'AUTH_APP.DOWNSTREAM_TIMEOUT': [504, 'dependency', 'The authentication service timed out.'],
  'AUTH_APP.DOWNSTREAM_FAILED': [502, 'dependency', 'The authentication service could not complete the request.'],
  'AUTH_APP.INVALID_BODY': [400, 'validation', 'The authentication request body is invalid.'],
  'AUTH_APP.INVALID_REQUEST': [422, 'validation', 'The authentication request is invalid.'],
  'AUTH_CORE.INVALID_BODY': [400, 'validation', 'The authentication request body is invalid.'],
  'AUTH_CORE.INVALID_REQUEST': [422, 'validation', 'The authentication request is invalid.']
});

export function validRecoveryUrl(value) {
  if (typeof value !== 'string' || value.length > 2048 || value.trim() !== value) return false;
  try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash && url.href === value; }
  catch { return false; }
}

function validNavigation(value) {
  return typeof value === 'string' && value.startsWith('/') && !value.startsWith('//') && !/[\\\s]/u.test(value);
}
function publicState(value, path) {
  const keys = Object.keys(value ?? {}).filter(key => key !== 'ok' && key !== 'rid').sort().join(',');
  if (path.endsWith('/recover')) return keys === 'recoveryRequested' && value.recoveryRequested === true;
  if (path.endsWith('/clear')) return keys === 'cleared' && value.cleared === true;
  if (!path.endsWith('/complete') && keys === 'authorized,email,expiresAt') return value.authorized === true &&
    Number.isSafeInteger(value.expiresAt) && value.expiresAt > Date.now() && (value.email === null || typeof value.email === 'string');
  return !path.endsWith('/verify') && keys === 'authorized,passwordUpdated,sessionsRevoked' && value.authorized === false && value.passwordUpdated === true && typeof value.sessionsRevoked === 'boolean';
}
export function recoveryClient(config, post, ErrorType) {
  function settings() {
    const value = config.recovery;
    if (!value?.enabled || !validRecoveryUrl(value.returnUrl) || !validNavigation(value.successUrl) || !validNavigation(value.errorUrl)) {
      throw new ErrorType(RECOVERY_ERRORS['AUTH_APP.RECOVERY_NOT_CONFIGURED'][2], { code: 'AUTH_APP.RECOVERY_NOT_CONFIGURED', retryable: false });
    }
    return value;
  }
  async function operation(path, body, options, uncertain = false) {
    settings();
    try {
      const value = await post(path, body, options);
      const text = JSON.stringify(value);
      if (/"(?:accessToken|refreshToken|access_token|refresh_token|recoveryToken)"/u.test(text)) throw new ErrorType('Unsafe recovery response.', { code: 'auth_response_invalid' });
      if (!publicState(value, path)) throw new ErrorType('Invalid recovery response.', { code: 'auth_response_invalid' });
      return value;
    } catch (error) {
      if (uncertain && (['auth_timeout', 'auth_network_error', 'auth_response_invalid', 'auth_invalid_json'].includes(error?.code) || error?.name === 'AbortError')) {
        throw new ErrorType(RECOVERY_ERRORS['AUTH_APP.RECOVERY_UNCERTAIN'][2], { code: 'AUTH_APP.RECOVERY_UNCERTAIN', retryable: false });
      }
      throw error;
    }
  }
  return {
    async requestPasswordRecovery(email, options = {}) {
      const value = await operation('/token/password/recover', { email, redirectTo: settings().returnUrl, ...(options.captchaToken === undefined ? {} : { captchaToken: options.captchaToken }) }, options);
      if (value.recoveryRequested !== true) throw new ErrorType('Invalid recovery response.', { code: 'auth_response_invalid' });
      return { recoveryRequested: true };
    },
    async verifyPasswordRecovery(tokenHash, options = {}) {
      if (typeof tokenHash !== 'string' || !/^[A-Za-z0-9_-]{1,4096}$/u.test(tokenHash)) throw new ErrorType(RECOVERY_ERRORS['AUTH_CORE.RECOVERY_EXPIRED'][2], { code: 'AUTH_CORE.RECOVERY_EXPIRED' });
      try { await operation('/session/recovery/clear', {}, options); }
      catch { throw new ErrorType('The previous recovery context could not be cleared. Reopen your recovery link.', { code: 'auth_recovery_context_clear_failed', retryable: false }); }
      return operation('/token/password/recovery/verify', { tokenHash }, options, true);
    },
    getPasswordRecoveryContext(options = {}) { return operation('/token/password/recovery/context', {}, options); },
    completePasswordRecovery(password, options = {}) { return operation('/token/password/recovery/complete', { password }, options, true); },
    clearPasswordRecovery(options = {}) { return operation('/session/recovery/clear', {}, options); }
  };
}
