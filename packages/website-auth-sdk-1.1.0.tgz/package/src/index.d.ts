export type PasswordRecoveryConfig = Readonly<{
  enabled: boolean;
  /** Complete canonical HTTPS page URL, with no query or fragment. */
  returnUrl: string;
  successUrl: string;
  errorUrl: string;
}>;
export type PasswordRecoveryAuthorized = Readonly<{ authorized: true; expiresAt: number; email: string | null }>;
export type PasswordRecoveryCompleted = Readonly<{ authorized: false; passwordUpdated: true; sessionsRevoked: boolean }>;
export type PasswordRecoveryState = PasswordRecoveryAuthorized | PasswordRecoveryCompleted;

export type OAuthProvider = "apple" | "github" | "google";

export const OAUTH_PROVIDERS: readonly OAuthProvider[];

export type AuthUser = Readonly<{
  id: string;
  email: string | null;
  phone: string | null;
  role: string | null;
  aud: string | null;
  emailConfirmedAt: string | null;
  phoneConfirmedAt: string | null;
  lastSignInAt: string | null;
  createdAt: string | null;
  updatedAt: string | null;
  displayName: string | null;
  companyName: string | null;
  billingName: string | null;
  billingAddressLine1: string | null;
  billingAddressLine2: string | null;
  billingCity: string | null;
  billingPostalCode: string | null;
  billingCountryCode: string | null;
  billingTaxId: string | null;
}>;

export type CookieAuthSession = Readonly<{
  authenticated: true;
  tokenType: "bearer";
  expiresIn: number;
  expiresAt: number;
}>;

export type CookieAuthSuccess = Readonly<{
  session: CookieAuthSession;
  user: AuthUser;
}>;

export type CookieSignupSuccess = Readonly<{
  confirmationRequired: boolean;
  session: CookieAuthSession | null;
  user: AuthUser;
}>;

export type AuthRedirectResult = Readonly<{
  kind: "session" | "error";
  message?: string;
}>;

export type WebsiteAuthConfig = Readonly<{
  persistSession?: boolean;
  recovery?: PasswordRecoveryConfig;
  getRecoveryConfig?: () => PasswordRecoveryConfig;
  authBaseUrl?: string;
  storageKey: string;
  requestIdPrefix: string;
  googleClientId?: string | null;
  getOAuthCallbackUrl: () => string;
  oauthSuccessUrl: string;
  oauthFailureUrl: string;
  legacyLocalStorageKeys?: readonly string[];
}>;

export type WebsiteAuthResolvedConfig = Readonly<{
  persistSession: boolean;
  recovery: PasswordRecoveryConfig | null;
  authBaseUrl: string;
  storageKey: string;
  redirectResultKey: string;
  oauthPendingKey: string;
  requestIdPrefix: string;
  googleClientId: string | null;
  getOAuthCallbackUrl: () => string;
  oauthSuccessUrl: string;
  oauthFailureUrl: string;
  legacyLocalStorageKeys: readonly string[];
}>;

export type GoogleOneTapHandlers = Readonly<{
  onCredentialReceived: () => void;
  onSuccess: (result: CookieAuthSuccess) => void;
  onError: (error: unknown) => void;
  onPromptUnavailable?: () => void;
  onPromptDismissed?: () => void;
}>;

export class WebsiteAuthError extends Error {
  readonly code: string;
  readonly status: number;
  readonly retryable: boolean;
  readonly action: string | null;
  readonly field: string | null;
  readonly rid: string | null;
  constructor(
    message: string,
    options?: {
      code?: string;
      status?: number;
      retryable?: boolean;
      action?: string | null;
      field?: string | null;
      rid?: string | null;
    }
  );
}

export type CookieWebsiteAuthClient = Readonly<{
  config: WebsiteAuthResolvedConfig;
  postAuthJson<T>(
    path: string,
    body: Record<string, unknown>,
    options?: { signal?: AbortSignal }
  ): Promise<T>;
  readStoredSession(): (CookieAuthSession & { user: AuthUser }) | null;
  storeAuthResult(result: unknown): CookieAuthSession & { user: AuthUser };
  clearStoredSession(): void;
  loginWithPasswordResult(
    email: string,
    password: string,
    captchaToken?: string
  ): Promise<CookieAuthSuccess>;
  requestPasswordRecovery(email: string, options?: { captchaToken?: string; signal?: AbortSignal }): Promise<{ recoveryRequested: true }>;
  verifyPasswordRecovery(tokenHash: string, options?: { signal?: AbortSignal }): Promise<PasswordRecoveryAuthorized>;
  getPasswordRecoveryContext(options?: { signal?: AbortSignal }): Promise<PasswordRecoveryState>;
  completePasswordRecovery(password: string, options?: { signal?: AbortSignal }): Promise<PasswordRecoveryCompleted>;
  clearPasswordRecovery(options?: { signal?: AbortSignal }): Promise<{ cleared: true }>;
  confirmEmail(tokenHash: string, options?: { signal?: AbortSignal }): Promise<CookieAuthSuccess>;
  signupWithPassword(input: {
    email: string;
    password: string;
    displayName: string;
    companyName?: string;
    redirectTo: string;
    captchaToken?: string;
  }): Promise<CookieSignupSuccess>;
  prepareGoogleOneTap(): Promise<void>;
  isGoogleOneTapReady(): boolean;
  offerGoogleOneTap(handlers: GoogleOneTapHandlers, signal?: AbortSignal): Promise<void>;
  startOAuthRedirect(provider: OAuthProvider): Promise<string>;
  completeOAuthRedirectCallback(): Promise<boolean>;
  readAuthRedirectResult(): AuthRedirectResult | null;
  getValidStoredSession(): Promise<(CookieAuthSession & { user: AuthUser }) | null>;
  logout(): Promise<void>;
}>;


export type WebsiteAuthFlowConfig = WebsiteAuthConfig & Readonly<{
  signedOutUrl: string;
  isProtectedRoute: (url: URL) => boolean;
  isRecoveryRoute?: (url: URL) => boolean;
  getSuccessUrl?: () => string | Promise<string>;
  gateWhenHidden?: boolean;
  isAuthRoute?: (url: URL) => boolean;
  getCaptchaToken?: (signal: AbortSignal) => Promise<string>;
  onAuthenticated?: (result: CookieAuthSuccess, action: 'login' | 'signup' | 'oauth') => void | Promise<void>;
  navigate?: (url: string, options: { replace: boolean }) => void | Promise<void>;
}>;
export type WebsiteAuthFlowState = Readonly<{
  phase: 'checking' | 'authenticated' | 'anonymous' | 'unavailable' | 'recovery';
  session: (CookieAuthSession & { user: AuthUser }) | null;
  user: AuthUser | null;
  action: string | null;
  busy: boolean;
  error: Error | null;
  message: string | null;
  canRenderProtected: boolean;
  recovery: PasswordRecoveryState | null;
}>;
export type WebsiteAuthFlow = Readonly<{
  state: WebsiteAuthFlowState;
  subscribe(listener: (state: WebsiteAuthFlowState) => void): () => void;
  start(): Promise<unknown>;
  verify(options?: { refresh?: boolean }): Promise<(CookieAuthSession & { user: AuthUser }) | null>;
  routeChanged(): Promise<unknown>;
  pageShown(): Promise<unknown>;
  visibilityChanged(hidden: boolean): Promise<unknown>;
  storageChanged(key: string | null): Promise<unknown>;
  invalidateSession(): void;
  login(email: string, password: string, captchaToken?: string): Promise<CookieAuthSuccess | null>;
  signup(input: Parameters<CookieWebsiteAuthClient['signupWithPassword']>[0]): Promise<CookieSignupSuccess | null>;
  oauth(provider: OAuthProvider): Promise<unknown>;
  completeOAuthRedirectCallback(): Promise<unknown>;
  logout(): Promise<void>;
  confirmEmail(tokenHash: string): Promise<CookieAuthSuccess | null>;
  requestPasswordRecovery(email: string, options?: { captchaToken?: string; signal?: AbortSignal }): Promise<unknown>;
  verifyPasswordRecovery(tokenHash: string, options?: { signal?: AbortSignal }): Promise<PasswordRecoveryAuthorized | null>;
  getPasswordRecoveryContext(options?: { signal?: AbortSignal }): Promise<PasswordRecoveryState | null>;
  completePasswordRecovery(password: string, options?: { signal?: AbortSignal }): Promise<PasswordRecoveryCompleted | null>;
  clearPasswordRecovery(): Promise<unknown>;
  runAuthenticated<T>(operation: (session: CookieAuthSession & { user: AuthUser }) => Promise<T>): Promise<T>;
  requestAccountPasswordRecovery(email: string, redirectTo: string, captchaToken?: string): Promise<unknown>;
  updateAccountProfile(input: Record<string, unknown>): Promise<AuthUser | null>;
  updateAccountPassword(input: { currentPassword?: string; password: string; nonce?: string }): Promise<unknown>;
  ensureAppAccess(): Promise<unknown>;
  dispose(): void;
}>;
export function createWebsiteAuthFlow(config: WebsiteAuthFlowConfig): WebsiteAuthFlow;
export function attachWebsiteAuthFlow(flow: WebsiteAuthFlow, document?: Document, window?: Window): () => void;
