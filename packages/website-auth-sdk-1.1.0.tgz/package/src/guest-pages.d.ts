export function createPagesGuestHandler(config:{projectId:string;bindingName?:string}):
  (context:{request:Request;env:Record<string,unknown>})=>Promise<Response>;
