export type PagesAuthHandlerOptions = Readonly<{
  appSlug: string;
  allowedEmail?: string;
  recovery?: Readonly<{
    enabled: boolean;
    returnUrls: readonly string[];
    contextMaxAgeSeconds: number;
    cookieName?: string;
  }>;
  bindingName?: string;
  internalOrigin?: string;
  accessCookieName?: string;
  refreshCookieName?: string;
  refreshCookieMaxAgeSeconds?: number;
}>;

export type PagesAuthContext = Readonly<{
  request: Request;
  params?: { path?: string[] };
  env?: Record<string, unknown>;
}>;

export type AuthCookieNames = Readonly<{
  accessCookieName: string;
  refreshCookieName: string;
}>;

export const WEBSITE_AUTH_ROUTES: readonly string[];
export const COOKIE_WEBSITE_AUTH_ROUTES: readonly string[];
export const COOKIE_SESSION_LOGOUT_ROUTE: "session/logout";

export function defaultAuthCookieNames(appSlug: string): AuthCookieNames;

/**
 * Cookie-only Pages facade. Projects Worker tokens into `__Host-*` HttpOnly
 * cookies and returns public session metadata only.
 */
export function createPagesAuthHandler(
  options: PagesAuthHandlerOptions
): (context: PagesAuthContext) => Promise<Response>;

/** Alias for `createPagesAuthHandler`. */
export function createCookiePagesAuthHandler(
  options: PagesAuthHandlerOptions
): (context: PagesAuthContext) => Promise<Response>;

/** Return null only for the configured verified identity; otherwise deny. */
export function createPagesAccessGuard(
  options: PagesAuthHandlerOptions & { allowedEmail: string }
): (context: PagesAuthContext) => Promise<Response | null>;

/** Protect every website path except auth endpoints and explicit login assets. */
export function createPagesWebsiteGuard(
  options: PagesAuthHandlerOptions & {
    allowedEmail: string;
    signInPath: string;
    publicPaths: readonly string[];
  }
): (context: PagesAuthContext & { next(): Response | Promise<Response> }) => Promise<Response>;
