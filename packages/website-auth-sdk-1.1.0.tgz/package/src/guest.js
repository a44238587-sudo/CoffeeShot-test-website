/** Controlled guest errors share the server envelope's observable fields. */
export class GuestSessionError extends Error {
  constructor(message,{code='guest_session_failed',status=0,category='internal',retryable=false,rid=null,retryAfter=null}={}) {
    super(message);this.name='GuestSessionError';Object.assign(this,{code,status,category,retryable,rid,retryAfter});
  }
}

/** Validate credentials before exposing them to a product's public API adapter. */
function session(value,projectId,now) {
  if(!value||typeof value!=='object'||Array.isArray(value)||
    Object.keys(value).sort().join(',')!=='expiresAt,projectId,subjectId,token'||
    value.projectId!==projectId||typeof value.subjectId!=='string'||!/^guest_[a-f0-9]{32}$/.test(value.subjectId)||
    typeof value.token!=='string'||!/^g_[a-f0-9]{64}$/.test(value.token)||
    !Number.isSafeInteger(value.expiresAt)||value.expiresAt<=now) {
    throw new GuestSessionError('The guest session response is invalid.',{code:'guest_response_invalid',category:'dependency'});
  }
  return Object.freeze({...value});
}

/**
 * Optional headless guest lifecycle. Construction performs no network/storage I/O.
 * Call ensure() only from an explicit product interaction; there are no timers.
 * Guest credentials stay in memory, separate from authenticated HttpOnly sessions.
 */
export function createGuestSession({endpoint,projectId,fetch:fetchImpl=globalThis.fetch,now=Date.now,timeoutMs=10000}) {
  const url=new URL(endpoint,globalThis.location?.origin);
  if(url.protocol!=='https:'||url.username||url.password||url.hash||url.search||
    typeof projectId!=='string'||!/^[a-zA-Z0-9_.:@-]{1,160}$/.test(projectId)||
    typeof fetchImpl!=='function'||!Number.isSafeInteger(timeoutMs)||timeoutMs<1||timeoutMs>60000)throw new TypeError('Invalid guest configuration.');
  let state=Object.freeze({phase:'idle',session:null,error:null}),pending=null,controller=null,epoch=0,disposed=false;
  const listeners=new Set();
  function publish(next){state=Object.freeze(next);for(const listener of listeners)listener(state);}
  function reset(){epoch++;controller?.abort();controller=null;pending=null;publish({phase:'idle',session:null,error:null});}
  return Object.freeze({
    get state(){return state;},
    subscribe(listener){if(disposed)throw new Error('Guest session disposed.');listeners.add(listener);listener(state);return()=>listeners.delete(listener);},
    ensure(){
      if(disposed)return Promise.reject(new GuestSessionError('Guest session disposed.',{code:'guest_disposed'}));
      if(state.session&&state.session.expiresAt>now()+30000)return Promise.resolve(state.session);
      if(pending)return pending;
      const current=++epoch,abort=new AbortController();controller=abort;
      const rid=crypto.randomUUID(),timer=setTimeout(()=>abort.abort(),timeoutMs);
      publish({phase:'pending',session:null,error:null});
      pending=(async()=>{
        try {
          const response=await fetchImpl(url.href,{method:'POST',credentials:'omit',redirect:'error',signal:abort.signal,
            headers:{'content-type':'application/json','x-request-id':rid},body:JSON.stringify({projectId})});
          const reader=response.body?.getReader(),chunks=[];let bytes=0;
          if(!reader)throw new GuestSessionError('The guest response is empty.',{code:'guest_response_invalid'});
          try {
            while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;
              if(bytes>16384){await reader.cancel();throw new GuestSessionError('The guest response is too large.',{code:'guest_response_invalid'});}chunks.push(value);}
          }finally{reader.releaseLock();}
          const body=new Uint8Array(bytes);let offset=0;for(const chunk of chunks){body.set(chunk,offset);offset+=chunk.byteLength;}
          const text=new TextDecoder().decode(body);
          let data;try{data=JSON.parse(text);}catch{throw new GuestSessionError('The guest response is invalid.',{code:'guest_response_invalid'});}
          if(data?.rid!==rid||response.headers.get('x-request-id')!==rid)throw new GuestSessionError('The guest response identifier is invalid.',{code:'guest_response_invalid'});
          if(!response.ok){
            const e=data?.error;
            if(data?.ok!==false||!e||Object.keys(e).sort().join(',')!=='category,code,message,retryable'||
              typeof e.code!=='string'||typeof e.message!=='string'||typeof e.category!=='string'||typeof e.retryable!=='boolean')throw new GuestSessionError('The guest error response is invalid.',{code:'guest_response_invalid'});
            const retry=response.headers.get('retry-after');
            throw new GuestSessionError(e.message,{...e,status:response.status,rid,retryAfter:retry&&/^\d+$/.test(retry)?Number(retry):null});
          }
          if(data.ok!==true||Object.keys(data).sort().join(',')!=='ok,rid,session')throw new GuestSessionError('The guest response is invalid.',{code:'guest_response_invalid'});
          const issued=session(data.session,projectId,now());
          if(current!==epoch||disposed)throw new GuestSessionError('The guest request was superseded.',{code:'guest_session_changed'});
          publish({phase:'ready',session:issued,error:null});return issued;
        }catch(cause){
          const error=cause instanceof GuestSessionError?cause:new GuestSessionError('The guest service is unavailable.',{code:'guest_unavailable',category:'dependency',retryable:true,rid});
          if(current===epoch&&!disposed)publish({phase:'error',session:null,error});
          throw error;
        }finally{clearTimeout(timer);if(current===epoch){pending=null;controller=null;}}
      })();
      return pending;
    },
    invalidate(){if(!disposed)reset();},
    authenticated(){if(!disposed)reset();},
    dispose(){if(disposed)return;disposed=true;epoch++;controller?.abort();pending=null;controller=null;listeners.clear();state=Object.freeze({phase:'disposed',session:null,error:null});}
  });
}
