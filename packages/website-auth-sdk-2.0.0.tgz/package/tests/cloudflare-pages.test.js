import assert from "node:assert/strict";
import test from "node:test";

import {
  COOKIE_SESSION_LOGOUT_ROUTE,
  COOKIE_WEBSITE_AUTH_ROUTES,
  WEBSITE_AUTH_ROUTES,
  createCookiePagesAuthHandler,
  createPagesAuthHandler,
  defaultAuthCookieNames,
} from "../src/cloudflare-pages.js";

const REQUEST_ID = "test-auth-1";
const ACCESS = "access-token-value";
const REFRESH = "refresh-token-value";

function publicUser(overrides = {}) {
  return {
    id: "11111111-1111-4111-8111-111111111111",
    email: "user@example.com",
    phone: null,
    role: null,
    aud: null,
    emailConfirmedAt: null,
    phoneConfirmedAt: null,
    lastSignInAt: null,
    createdAt: null,
    updatedAt: null,
    displayName: "Ada",
    companyName: null,
    billingName: null,
    billingAddressLine1: null,
    billingAddressLine2: null,
    billingCity: null,
    billingPostalCode: null,
    billingCountryCode: null,
    billingTaxId: null,
    ...overrides,
  };
}

function privateSession(overrides = {}) {
  return {
    accessToken: ACCESS,
    refreshToken: REFRESH,
    tokenType: "bearer",
    expiresIn: 3600,
    expiresAt: 2_000_000_000,
    ...overrides,
  };
}

function sessionPayload(overrides = {}) {
  return {
    ok: true,
    rid: REQUEST_ID,
    grantType: "password",
    session: privateSession(),
    user: publicUser(),
    ...overrides,
  };
}

function setCookieHeader(response) {
  return typeof response.headers.getSetCookie === "function"
    ? response.headers.getSetCookie().join("\n")
    : response.headers.get("set-cookie") ?? "";
}

function createContext({
  route = "token/password/login",
  method = "POST",
  body = {},
  headers = {},
  search = "",
  env,
  cookieHandler = null,
}) {
  const handler =
    cookieHandler ??
    createPagesAuthHandler({
      appSlug: "my-product",
      bindingName: "AUTH_SUPABASE_APP",
    });
  const request = new Request(`https://example.com/api/auth/${route}${search}`, {
    method,
    headers: {
      "content-type": "application/json",
      "x-request-id": REQUEST_ID,
      ...headers,
    },
    body: method === "POST" ? JSON.stringify(body) : undefined,
  });
  return handler({
    request,
    params: { path: route.split("/") },
    env,
  });
}

function mockService(fetchImpl) {
  return {
    AUTH_SUPABASE_APP: {
      fetch: fetchImpl,
    },
  };
}

test("default cookie names follow the Host-appSlug scheme", () => {
  assert.deepEqual(defaultAuthCookieNames("coffeeframe"), {
    accessCookieName: "__Host-coffeeframe-access",
    refreshCookieName: "__Host-coffeeframe-refresh",
  });
  assert.deepEqual(defaultAuthCookieNames("my-product"), {
    accessCookieName: "__Host-my-product-access",
    refreshCookieName: "__Host-my-product-refresh",
  });
});

test("cookie route allowlist includes session/logout", () => {
  assert.equal(WEBSITE_AUTH_ROUTES.includes(COOKIE_SESSION_LOGOUT_ROUTE), true);
  assert.equal(COOKIE_WEBSITE_AUTH_ROUTES, WEBSITE_AUTH_ROUTES);
  assert.equal(COOKIE_SESSION_LOGOUT_ROUTE, "session/logout");
});

test("createPagesAuthHandler is cookie-only by default and matches the cookie alias", async () => {
  const pagesHandler = createPagesAuthHandler({ appSlug: "my-product" });
  const aliasHandler = createCookiePagesAuthHandler({ appSlug: "my-product" });
  const env = mockService(() => Response.json(sessionPayload()));
  const pagesResponse = await createContext({ cookieHandler: pagesHandler, env });
  const aliasResponse = await createContext({
    cookieHandler: aliasHandler,
    env: mockService(() => Response.json(sessionPayload())),
  });
  const pagesPayload = await pagesResponse.json();
  const aliasPayload = await aliasResponse.json();
  assert.equal(pagesPayload.session.authenticated, true);
  assert.equal(Object.hasOwn(pagesPayload.session, "accessToken"), false);
  assert.match(setCookieHeader(pagesResponse), /__Host-my-product-access=/);
  assert.equal(aliasPayload.session.authenticated, true);
  assert.equal(Object.hasOwn(aliasPayload.session, "accessToken"), false);
  assert.match(setCookieHeader(aliasResponse), /__Host-my-product-refresh=/);
});

test("cookie login sets Host cookies and strips tokens from JSON", async () => {
  let forwarded = null;
  const response = await createContext({
    body: { email: "user@example.com", password: "secret" },
    env: mockService(async input => {
      forwarded = input;
      return Response.json(sessionPayload());
    }),
  });
  const payload = await response.json();
  const cookies = setCookieHeader(response);

  assert.equal(response.status, 200);
  assert.equal(new URL(forwarded.url).pathname, "/my-product/token/password/login");
  assert.equal(forwarded.headers.get("cookie"), null);
  assert.equal(forwarded.headers.get("authorization"), null);
  assert.equal(payload.session.authenticated, true);
  assert.equal(payload.session.tokenType, "bearer");
  assert.equal(payload.session.expiresIn, 3600);
  assert.equal(payload.session.expiresAt, 2_000_000_000);
  assert.equal(Object.hasOwn(payload.session, "accessToken"), false);
  assert.equal(Object.hasOwn(payload.session, "refreshToken"), false);
  assert.doesNotMatch(JSON.stringify(payload), /access-token-value|refresh-token-value/);
  assert.match(cookies, /__Host-my-product-access=access-token-value/);
  assert.match(cookies, /__Host-my-product-refresh=refresh-token-value/);
  assert.match(cookies, /HttpOnly/);
  assert.match(cookies, /Secure/);
  assert.match(cookies, /SameSite=Lax/);
  assert.match(cookies, /Path=\//);
  assert.match(cookies, /Max-Age=3600/);
  assert.match(cookies, /Max-Age=31536000/);
  assert.equal(response.headers.get("cache-control"), "private, no-store");
});

test("OAuth exchange and id-token grants set the same cookie pair", async t => {
  for (const [route, grantType] of [
    ["token/google/exchange", "pkce"],
    ["token/google/id-token", "id_token"],
    ["token/apple/exchange", "pkce"],
    ["token/github/exchange", "pkce"],
  ]) {
    await t.test(route, async () => {
      const response = await createContext({
        route,
        env: mockService(() =>
          Response.json(sessionPayload({ grantType }))
        ),
      });
      const payload = await response.json();
      assert.equal(payload.grantType, grantType);
      assert.equal(Object.hasOwn(payload.session, "accessToken"), false);
      assert.match(setCookieHeader(response), /__Host-my-product-access=/);
    });
  }
});

test("signup with a session sets cookies; confirmation-only signup does not", async () => {
  const withSession = await createContext({
    route: "token/password/signup",
    env: mockService(() =>
      Response.json(sessionPayload({ grantType: "signup", confirmationRequired: false }))
    ),
  });
  assert.match(setCookieHeader(withSession), /__Host-my-product-access=/);
  assert.equal((await withSession.json()).confirmationRequired, false);

  const pending = await createContext({
    route: "token/password/signup",
    env: mockService(() =>
      Response.json({
        ok: true,
        rid: REQUEST_ID,
        grantType: "signup",
        confirmationRequired: true,
        session: null,
        user: publicUser(),
      })
    ),
  });
  assert.equal(setCookieHeader(pending), "");
  assert.equal((await pending.json()).session, null);
});

test("refresh reads the refresh cookie and ignores the browser body", async () => {
  let forwardedPayload = null;
  const response = await createContext({
    route: "token/refresh",
    headers: {
      cookie: "__Host-my-product-refresh=cookie-refresh-token",
    },
    body: { refreshToken: "browser-refresh-token" },
    env: mockService(async input => {
      forwardedPayload = await input.json();
      assert.equal(input.headers.get("cookie"), null);
      return Response.json(
        sessionPayload({
          grantType: "refresh_token",
          session: privateSession({
            accessToken: "next-access",
            refreshToken: "next-refresh",
          }),
        })
      );
    }),
  });
  const payload = await response.json();
  assert.deepEqual(forwardedPayload, { refreshToken: "cookie-refresh-token" });
  assert.equal(payload.session.authenticated, true);
  assert.equal(Object.hasOwn(payload.session, "refreshToken"), false);
  assert.match(setCookieHeader(response), /__Host-my-product-access=next-access/);
  assert.match(setCookieHeader(response), /__Host-my-product-refresh=next-refresh/);
});

test("authenticated routes inject the access cookie and drop Cookie plus browser Authorization", async () => {
  let forwarded = null;
  const response = await createContext({
    route: "verify",
    headers: {
      authorization: "Bearer browser-supplied-value",
      cookie: "__Host-my-product-access=server-access-token",
    },
    body: { includeUser: true },
    env: mockService(async input => {
      forwarded = input;
      return Response.json({
        ok: true,
        rid: REQUEST_ID,
        valid: true,
        reason: "ok",
        user: publicUser(),
      });
    }),
  });
  assert.equal(forwarded.headers.get("authorization"), "Bearer server-access-token");
  assert.equal(forwarded.headers.get("cookie"), null);
  assert.equal((await response.json()).valid, true);
  assert.equal(setCookieHeader(response), "");
});

test("account/logout injects the access cookie and then clears both cookies", async () => {
  let forwarded = null;
  const response = await createContext({
    route: "account/logout",
    headers: { cookie: "__Host-my-product-access=server-access-token" },
    body: { scope: "global" },
    env: mockService(async input => {
      forwarded = input;
      return Response.json({
        ok: true,
        rid: REQUEST_ID,
        loggedOut: true,
        scope: "global",
      });
    }),
  });
  const cookies = setCookieHeader(response);
  assert.equal(forwarded.headers.get("authorization"), "Bearer server-access-token");
  assert.match(cookies, /__Host-my-product-access=;/);
  assert.match(cookies, /__Host-my-product-refresh=;/);
  assert.match(cookies, /Max-Age=0/);
});

test("session/logout clears cookies without calling the Worker", async () => {
  let called = false;
  const response = await createContext({
    route: "session/logout",
    env: mockService(() => {
      called = true;
      return Response.json({ ok: true });
    }),
  });
  const cookies = setCookieHeader(response);
  assert.equal(called, false);
  assert.deepEqual(await response.json(), { ok: true, rid: REQUEST_ID });
  assert.match(cookies, /__Host-my-product-access=/);
  assert.match(cookies, /__Host-my-product-refresh=/);
  assert.match(cookies, /Max-Age=0/);
});

test("401 and failed refresh clear both cookies and never leak upstream secrets", async () => {
  const unauthorized = await createContext({
    route: "verify",
    env: mockService(() =>
      Response.json(
        { ok: false, error: { message: "nope" }, refreshToken: "leaked-refresh" },
        { status: 401, headers: { "set-cookie": "attacker=stolen; HttpOnly" } }
      )
    ),
  });
  const unauthorizedBody = await unauthorized.text();
  assert.equal(unauthorized.status, 401);
  assert.doesNotMatch(unauthorizedBody, /leaked-refresh|stolen/);
  assert.doesNotMatch(setCookieHeader(unauthorized), /attacker|stolen/);
  assert.match(setCookieHeader(unauthorized), /__Host-my-product-access=;/);
  assert.match(setCookieHeader(unauthorized), /Max-Age=0/);

  const failedRefresh = await createContext({
    route: "token/refresh",
    headers: { cookie: "__Host-my-product-refresh=stale" },
    env: mockService(() => Response.json({ ok: false }, { status: 400 })),
  });
  assert.equal(failedRefresh.status, 400);
  assert.match(setCookieHeader(failedRefresh), /Max-Age=0/);
});

test("verify valid=false clears cookies", async () => {
  const response = await createContext({
    route: "verify",
    headers: { cookie: "__Host-my-product-access=expired-access" },
    env: mockService(() =>
      Response.json({
        ok: true,
        rid: REQUEST_ID,
        valid: false,
        reason: "invalid_or_expired_token",
      })
    ),
  });
  assert.equal((await response.json()).valid, false);
  assert.match(setCookieHeader(response), /Max-Age=0/);
});

test("invalid or leaky success payloads become 502 without setting cookies", async () => {
  const leaked = await createContext({
    env: mockService(() =>
      Response.json({
        ...sessionPayload(),
        nested: { accessToken: "must-not-reach-browser" },
      })
    ),
  });
  const leakedPayload = await leaked.json();
  assert.equal(leaked.status, 502);
  assert.equal(leakedPayload.error.code, "auth_response_invalid");
  assert.doesNotMatch(JSON.stringify(leakedPayload), /must-not-reach-browser|access-token-value/);
  assert.equal(setCookieHeader(leaked), "");

  const notJson = await createContext({
    env: mockService(() => new Response("not-json", { status: 200 })),
  });
  assert.equal(notJson.status, 502);
  assert.equal(setCookieHeader(notJson), "");

  const missingExpiry = await createContext({
    env: mockService(() =>
      Response.json(
        sessionPayload({
          session: { accessToken: ACCESS, refreshToken: REFRESH, tokenType: "bearer" },
        })
      )
    ),
  });
  assert.equal(missingExpiry.status, 502);
  assert.equal(setCookieHeader(missingExpiry), "");
});

test("OAuth start does not set cookies and still strips unexpected tokens", async () => {
  const response = await createContext({
    route: "token/google/start",
    env: mockService(() =>
      Response.json({
        ok: true,
        rid: REQUEST_ID,
        url: "https://accounts.google.com/o/oauth2/v2/auth",
      })
    ),
  });
  const payload = await response.json();
  assert.equal(payload.url, "https://accounts.google.com/o/oauth2/v2/auth");
  assert.equal(setCookieHeader(response), "");
});

test("cookie names are configurable", async () => {
  const handler = createPagesAuthHandler({
    appSlug: "my-product",
    accessCookieName: "__Host-custom-access",
    refreshCookieName: "__Host-custom-refresh",
  });
  const response = await createContext({
    cookieHandler: handler,
    env: mockService(() => Response.json(sessionPayload())),
  });
  const cookies = setCookieHeader(response);
  assert.match(cookies, /__Host-custom-access=access-token-value/);
  assert.match(cookies, /__Host-custom-refresh=refresh-token-value/);
  assert.doesNotMatch(cookies, /__Host-my-product-/);
});

test("browser Authorization is ignored; tokens never reach the JSON body", async () => {
  let forwarded = null;
  const response = await createContext({
    headers: { authorization: "Bearer browser-token" },
    env: mockService(async input => {
      forwarded = input;
      return Response.json(sessionPayload());
    }),
  });
  const payload = await response.json();
  assert.equal(forwarded.headers.get("authorization"), null);
  assert.equal(Object.hasOwn(payload.session, "accessToken"), false);
  assert.equal(Object.hasOwn(payload.session, "refreshToken"), false);
  assert.match(setCookieHeader(response), /__Host-my-product-access=/);
});

test("cookie-only handler preserves method, route, query, request-id, and body-size checks", async () => {
  const cookie = createPagesAuthHandler({ appSlug: "my-product" });
  assert.equal(
    (await createContext({ method: "GET", cookieHandler: cookie, env: mockService(() => new Response()) }))
      .status,
    405
  );
  assert.equal(
    (await createContext({
      route: "not/a/route",
      cookieHandler: cookie,
      env: mockService(() => new Response()),
    })).status,
    404
  );
  assert.equal(
    (await createContext({
      search: "?x=1",
      cookieHandler: cookie,
      env: mockService(() => new Response()),
    })).status,
    404
  );
  const missingId = await cookie({
    request: new Request("https://example.com/api/auth/verify", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    }),
    params: { path: ["verify"] },
    env: mockService(() => new Response()),
  });
  assert.equal(missingId.status, 500);
  assert.equal((await missingId.json()).error.code, "request_id_required");

  const oversized = await createContext({
    headers: { "content-length": "70000" },
    env: mockService(() => Response.json(sessionPayload())),
  });
  assert.equal(oversized.status, 413);
  assert.equal((await oversized.json()).error.code, "AUTH_APP.BODY_TOO_LARGE");
});

test("invalid handler options fail closed", () => {
  assert.throws(() => createPagesAuthHandler({}), /appSlug/);
  assert.throws(() => createPagesAuthHandler({ appSlug: "MyProduct" }), /kebab-case/);
  assert.throws(
    () => createPagesAuthHandler({ appSlug: "my-product", sessionMode: "bearer" }),
    /sessionMode is not supported/
  );
  assert.throws(
    () => createPagesAuthHandler({ appSlug: "my-product", sessionMode: "cookie" }),
    /sessionMode is not supported/
  );
  assert.throws(
    () => createPagesAuthHandler({
      appSlug: "my-product",
      accessCookieName: "access token",
    }),
    /accessCookieName/
  );
  assert.throws(
    () => createPagesAuthHandler({
      appSlug: "my-product",
      accessCookieName: "__Host-same",
      refreshCookieName: "__Host-same",
    }),
    /must differ/
  );
});

test('storage-free OAuth pending state is same-origin, HttpOnly and consumed', async () => {
 const body={provider:'google',verifier:'a'.repeat(64),redirectTo:'https://example.com/auth/callback',createdAt:Date.now()};
 const denied=await createContext({route:'session/oauth/store',body,headers:{origin:'https://evil.example'}});
 assert.equal(denied.status,403);
 const stored=await createContext({route:'session/oauth/store',body,headers:{origin:'https://example.com'}});
 assert.equal(stored.status,200);
 const cookie=stored.headers.get('set-cookie');
 for(const flag of ['HttpOnly','Secure','SameSite=Lax','Path=/','Max-Age=300'])assert.ok(cookie.includes(flag));
 const result=await createContext({route:'session/oauth/consume',headers:{origin:'https://example.com',cookie:cookie.split(';')[0]}});
 assert.equal(result.status,200);assert.equal((await result.json()).pending.verifier,body.verifier);
 assert.ok(result.headers.get('set-cookie').includes('Max-Age=0'));
 const invalid=await createContext({route:'session/oauth/store',body:{...body,redirectTo:'https://evil.example/callback'},headers:{origin:'https://example.com'}});
 assert.equal(invalid.status,400);
});

test('cookie OAuth completes through the facade with browser storage unavailable',async()=>{
 const {createCookieWebsiteAuth}=await import('../src/cookie-client.js');
 const previous={window:globalThis.window,fetch:globalThis.fetch};let cookie='',destination='';
 const forbidden=new Proxy({}, {get(){throw new Error('Storage forbidden');}});
 globalThis.window={crypto:globalThis.crypto,localStorage:forbidden,sessionStorage:forbidden,location:{origin:'https://example.com',href:'https://example.com/?code=provider-code',replace(url){destination=url;}}};
 const handler=createPagesAuthHandler({appSlug:'my-product',bindingName:'AUTH_SUPABASE_APP'});
 globalThis.fetch=async(url,init)=>{
  const request=new Request('https://example.com'+url,{...init,headers:{...init.headers,origin:'https://example.com',cookie}});
  const response=await handler({request,params:{path:String(url).replace('/api/auth/','').split('/')},env:{AUTH_SUPABASE_APP:{fetch:async upstream=>{
   if(upstream.url.endsWith('/start'))return Response.json({ok:true,url:'https://accounts.google.com/o/oauth2/auth'});
   const body=await upstream.json();assert.equal(body.code,'provider-code');assert.match(body.codeVerifier,/^[a-zA-Z0-9_-]{43}$/);
   return Response.json(sessionPayload({rid:upstream.headers.get("x-request-id"),session:privateSession({expiresAt:Math.floor(Date.now()/1000)+3600})}));
  }}}});
  const cookies=response.headers.getSetCookie();if(cookies.length)cookie=cookies.map(c=>c.split(';')[0]).join('; ');
  return response;
 };
 try {
  const auth=createCookieWebsiteAuth({persistSession:false,storageKey:'test',requestIdPrefix:'test',getOAuthCallbackUrl:()=> 'https://example.com/auth/callback/',oauthSuccessUrl:'/',oauthFailureUrl:'/?auth=failed'});
  assert.match(await auth.startOAuthRedirect('google'),/^https:\/\/accounts.google.com/);
  assert.equal(await auth.completeOAuthRedirectCallback({onSuccess: () => window.location.replace('/')}),true);assert.equal(destination,'/');assert.equal(auth.readStoredSession().authenticated,true);
 }finally {globalThis.window=previous.window;globalThis.fetch=previous.fetch;}
});

test('fresh browser without a refresh cookie is signed out without calling auth',async()=>{
 const response=await createContext({route:'token/refresh',env:{AUTH_SUPABASE_APP:{fetch(){throw new Error('Must not call auth');}}}});
 assert.equal(response.status,401);
});

test("email confirmation projects credentials into cookies only and requires confirmed identity", async () => {
  for (const confirmed of [true,false]) {
    let forwarded;
    const upstream=sessionPayload({grantType:"email"});
    upstream.user.emailConfirmedAt=confirmed?"2026-09-12T00:00:00Z":null;
    const response=await createContext({route:"token/email/confirm",body:{tokenHash:"test-confirmation"},env:mockService(async input=>{forwarded=input;return Response.json(upstream);})});
    assert.equal(new URL(forwarded.url).pathname,"/my-product/token/email/confirm");
    assert.equal(response.status,confirmed?200:502);
    assert.doesNotMatch(await response.text(),/access-token-value|refresh-token-value/);
    if(confirmed)assert.match(setCookieHeader(response),/__Host-my-product-access=access-token-value/);
    else assert.doesNotMatch(setCookieHeader(response),/access-token-value/);
  }
});

test('confirmation preserves the verified error code with controlled copy only',async()=>{
 const original={ok:false,rid:REQUEST_ID,error:{code:'AUTH_CORE.CONFIRMATION_EXPIRED',message:'PRIVATE_DIAGNOSTIC',category:'authentication',retryable:false}};
 for(const [patch,status,recognized] of [[{},401,true],[{rid:'wrong'},401,false],[{extra:true},401,false],[{error:{...original.error,code:'PRIVATE_UNKNOWN'}},401,false],[{error:{...original.error,extra:'secret'}},401,false],[{},403,false]]){
  const response=await createContext({route:'token/email/confirm',body:{tokenHash:'fixture'},env:mockService(async()=>Response.json({...original,...patch},{status}))});
  const payload=await response.json();
  assert.equal(payload.error.code,recognized?'AUTH_CORE.CONFIRMATION_EXPIRED':'auth_request_failed');
  if(recognized)assert.match(payload.error.message,/invalid or has expired/);
  assert.doesNotMatch(JSON.stringify(payload),/PRIVATE_|secret/);
 }
});
