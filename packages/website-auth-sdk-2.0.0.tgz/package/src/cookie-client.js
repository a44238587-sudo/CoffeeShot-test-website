import { recoveryClient } from "./recovery.js";
const GOOGLE_IDENTITY_SCRIPT_URL = "https://accounts.google.com/gsi/client";
const GOOGLE_IDENTITY_LOAD_TIMEOUT_MS = 5_000;
const REQUEST_TIMEOUT_MS = 15_000;
const MAX_RESPONSE_BYTES = 1_048_576;
const MAX_SESSION_LIFETIME_SECONDS = 31_536_000;
const SESSION_REFRESH_LEEWAY_SECONDS = 60;
const OAUTH_CALLBACK_MAX_AGE_MS = 5 * 60 * 1000;

export const OAUTH_PROVIDERS = Object.freeze(["apple", "github", "google"]);

let googleIdentityScriptPromise = null;

export class WebsiteAuthError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = "WebsiteAuthError";
    this.code = options.code ?? "auth_request_failed";
    this.status = options.status ?? 0;
    this.retryable = options.retryable === true;
    this.action = options.action ?? null;
    this.field = options.field ?? null;
    this.rid = options.rid ?? null;
  }
}

function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function nonEmptyString(value, field, maxLength = 256) {
  if (
    typeof value !== "string" ||
    value.length === 0 ||
    value.length > maxLength ||
    value.trim() !== value
  ) {
    throw new TypeError(`${field} must be a non-empty bounded string.`);
  }
  return value;
}

function normalizeBaseUrl(value) {
  const base = value ?? "/api/auth";
  nonEmptyString(base, "authBaseUrl", 2048);
  if (!base.startsWith("/") || base.startsWith("//") || base.endsWith("/")) {
    throw new TypeError("authBaseUrl must be a same-origin absolute path without a trailing slash.");
  }
  const parsed = new URL(base, "https://website-auth-sdk.invalid");
  if (parsed.origin !== "https://website-auth-sdk.invalid" || parsed.search || parsed.hash) {
    throw new TypeError("authBaseUrl must not contain an origin, query string, or fragment.");
  }
  return parsed.pathname;
}

function normalizeNavigationTarget(value, field) {
  nonEmptyString(value, field, 4096);
  if (value.startsWith("/") && !value.startsWith("//")) return value;
  const parsed = new URL(value);
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password
  ) {
    throw new TypeError(`${field} must be a safe absolute URL or same-origin path.`);
  }
  return parsed.href;
}

function normalizeConfig(input) {
  if (!isRecord(input)) throw new TypeError("Website auth configuration is required.");
  const storageKey = nonEmptyString(input.storageKey, "storageKey", 256);
  const requestIdPrefix = nonEmptyString(input.requestIdPrefix, "requestIdPrefix", 64);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(requestIdPrefix)) {
    throw new TypeError("requestIdPrefix must use lowercase kebab-case.");
  }
  if (typeof input.getOAuthCallbackUrl !== "function") {
    throw new TypeError("getOAuthCallbackUrl must be a function.");
  }
  const googleClientId = input.googleClientId == null || input.googleClientId === ""
    ? null
    : nonEmptyString(input.googleClientId, "googleClientId", 1024);
  const legacyLocalStorageKeys = input.legacyLocalStorageKeys ?? [];
  if (
    !Array.isArray(legacyLocalStorageKeys) ||
    legacyLocalStorageKeys.some(key => typeof key !== "string" || !key || key.length > 256)
  ) {
    throw new TypeError("legacyLocalStorageKeys must contain bounded strings.");
  }
  return Object.freeze({
    persistSession: input.persistSession !== false,
    get recovery() {
      const value = input.getRecoveryConfig ? input.getRecoveryConfig() : input.recovery;
      return value ? Object.freeze({ ...value }) : null;
    },
    authBaseUrl: normalizeBaseUrl(input.authBaseUrl),
    storageKey,
    redirectResultKey: `${storageKey}.redirect-result`,
    oauthPendingKey: `${storageKey}.oauth-redirect`,
    requestIdPrefix,
    googleClientId,
    getOAuthCallbackUrl: input.getOAuthCallbackUrl,
    oauthFailureUrl: normalizeNavigationTarget(input.oauthFailureUrl, "oauthFailureUrl"),
    legacyLocalStorageKeys: Object.freeze([...legacyLocalStorageKeys]),
  });
}

function publicError(payload, status) {
  const envelope = isRecord(payload) && isRecord(payload.error) ? payload.error : {};
  const message = typeof envelope.message === "string" && envelope.message.trim()
    ? envelope.message.trim()
    : `Authentication request failed (${status || "network"}).`;
  return new WebsiteAuthError(message, {
    code: typeof envelope.code === "string" ? envelope.code : "auth_request_failed",
    status,
    retryable: envelope.retryable === true,
    action: typeof envelope.action === "string" ? envelope.action : null,
    field: typeof envelope.field === "string" ? envelope.field : null,
    rid: typeof payload?.rid === "string" ? payload.rid : null,
  });
}

function invalidAuthResponse(message, status = 0) {
  return new WebsiteAuthError(message, {
    code: "auth_response_invalid",
    status,
    retryable: true,
  });
}

const USER_STRING_FIELDS = Object.freeze({
  email: 320,
  phone: 64,
  role: 128,
  aud: 128,
  emailConfirmedAt: 64,
  phoneConfirmedAt: 64,
  lastSignInAt: 64,
  createdAt: 64,
  updatedAt: 64,
  displayName: 256,
  companyName: 256,
  billingName: 160,
  billingAddressLine1: 160,
  billingAddressLine2: 160,
  billingCity: 120,
  billingPostalCode: 32,
  billingCountryCode: 2,
  billingTaxId: 64,
});

function nullableUserString(user, key, maxLength) {
  const value = user[key];
  if (value === null) return null;
  if (typeof value === "string" && value.length <= maxLength) return value;
  throw new WebsiteAuthError("The authentication service returned an invalid user.", {
    code: "auth_user_invalid",
    retryable: true,
  });
}

function normalizeAuthUser(payload) {
  const candidate = isRecord(payload) && "user" in payload ? payload.user : payload;
  if (
    !isRecord(candidate) ||
    typeof candidate.id !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(candidate.id)
  ) {
    throw new WebsiteAuthError("The authentication service returned an invalid user.", {
      code: "auth_user_invalid",
      retryable: true,
    });
  }
  return Object.freeze({
    id: candidate.id,
    ...Object.fromEntries(
      Object.entries(USER_STRING_FIELDS).map(([key, maxLength]) => [
        key,
        nullableUserString(candidate, key, maxLength),
      ])
    ),
  });
}

async function parseJson(response) {
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.toLowerCase().includes("application/json")) return null;
  const contentLength = response.headers.get("content-length");
  if (contentLength && /^\d+$/u.test(contentLength) && Number(contentLength) > MAX_RESPONSE_BYTES) {
    throw invalidAuthResponse("The authentication service returned an oversized response.", response.status);
  }
  try {
    if (response.body && typeof response.body.getReader === "function") {
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let byteLength = 0;
      let text = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        byteLength += value.byteLength;
        if (byteLength > MAX_RESPONSE_BYTES) {
          await reader.cancel();
          throw invalidAuthResponse("The authentication service returned an oversized response.", response.status);
        }
        text += decoder.decode(value, { stream: true });
      }
      text += decoder.decode();
      return JSON.parse(text);
    }
    if (typeof response.text === "function") {
      const text = await response.text();
      if (new TextEncoder().encode(text).byteLength > MAX_RESPONSE_BYTES) {
        throw invalidAuthResponse("The authentication service returned an oversized response.", response.status);
      }
      return JSON.parse(text);
    }
    return await response.json();
  } catch (error) {
    if (error instanceof WebsiteAuthError) throw error;
    return null;
  }
}

function secureRequestId(prefix) {
  if (typeof crypto === "undefined" || typeof crypto.getRandomValues !== "function") {
    throw new WebsiteAuthError("This browser cannot create secure request identifiers.", {
      code: "browser_unsupported",
    });
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  const suffix = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  return `${prefix}-${suffix}`;
}

function createAuthJsonRequester(config) {
  return async function postAuthJson(path, body, options = {}) {
    if (typeof path !== "string" || !path.startsWith("/") || path.startsWith("//")) {
      throw new TypeError("Auth request path must be a same-origin absolute path.");
    }
    if (!isRecord(body)) throw new TypeError("Auth request body must be an object.");
    const controller = new AbortController();
    let timedOut = false;
    const relayAbort = () => controller.abort(options.signal?.reason);
    if (options.signal?.aborted) relayAbort();
    else options.signal?.addEventListener("abort", relayAbort, { once: true });
    const timeout = globalThis.setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, REQUEST_TIMEOUT_MS);
    let response;
    let payload;
    try {
      response = await fetch(`${config.authBaseUrl}${path}`, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "content-type": "application/json",
          "x-request-id": secureRequestId(config.requestIdPrefix),
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      payload = await parseJson(response);
    } catch (error) {
      if (error instanceof WebsiteAuthError) throw error;
      if (controller.signal.aborted) {
        if (timedOut) {
          throw new WebsiteAuthError("The authentication request timed out.", {
            code: "auth_timeout",
            retryable: true,
          });
        }
        throw options.signal?.reason instanceof Error
          ? options.signal.reason
          : new DOMException("The authentication request was aborted.", "AbortError");
      }
      throw new WebsiteAuthError("The authentication service is temporarily unreachable.", {
        code: "auth_network_error",
        retryable: true,
      });
    } finally {
      globalThis.clearTimeout(timeout);
      options.signal?.removeEventListener("abort", relayAbort);
    }
    if (!response.ok) throw publicError(payload, response.status);
    if (!isRecord(payload) || payload.ok !== true) {
      throw new WebsiteAuthError("The authentication service returned an invalid response.", {
        code: "auth_response_invalid",
        status: response.status,
        retryable: true,
      });
    }
    return payload;
  };
}

function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/gu, "-").replace(/\//gu, "_").replace(/=+$/u, "");
}

function assertProvider(provider) {
  if (!OAUTH_PROVIDERS.includes(provider)) {
    throw new TypeError(`Unsupported OAuth provider: ${String(provider)}.`);
  }
  return provider;
}

function googleIdentity() {
  return globalThis.window?.google?.accounts?.id ?? null;
}

function loadGoogleIdentity() {
  if (googleIdentity()) return Promise.resolve();
  if (googleIdentityScriptPromise) return googleIdentityScriptPromise;
  const loadPromise = new Promise((resolve, reject) => {
    let settled = false;
    const finish = callback => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timeout);
      callback();
    };
    const unavailable = () => new WebsiteAuthError(
      "Google sign-in is temporarily unavailable.",
      { code: "google_script_unavailable", retryable: true }
    );
    const timeout = window.setTimeout(
      () => finish(() => reject(unavailable())),
      GOOGLE_IDENTITY_LOAD_TIMEOUT_MS
    );
    const existing = document.querySelector(`script[src="${GOOGLE_IDENTITY_SCRIPT_URL}"]`);
    const script = existing ?? document.createElement("script");
    script.addEventListener("load", () => finish(resolve), { once: true });
    script.addEventListener("error", () => finish(() => reject(unavailable())), { once: true });
    if (!existing) {
      script.src = GOOGLE_IDENTITY_SCRIPT_URL;
      script.async = true;
      script.defer = true;
      document.head.appendChild(script);
    }
  });
  googleIdentityScriptPromise = loadPromise.catch(error => {
    googleIdentityScriptPromise = null;
    throw error;
  });
  return googleIdentityScriptPromise;
}

function isGoogleOneTapReady(config) {
  return Boolean(
    typeof window !== "undefined" &&
    config.googleClientId &&
    window.crypto?.subtle &&
    googleIdentity()?.prompt
  );
}

async function prepareGoogleOneTap(config) {
  if (typeof window === "undefined") {
    throw new WebsiteAuthError("Native Google sign-in requires a browser.", {
      code: "browser_required",
    });
  }
  if (!config.googleClientId || !window.crypto?.subtle) {
    throw new WebsiteAuthError("Native Google sign-in is unavailable in this browser.", {
      code: "google_one_tap_unavailable",
    });
  }
  await loadGoogleIdentity();
  if (!isGoogleOneTapReady(config)) {
    throw new WebsiteAuthError("Native Google sign-in is temporarily unavailable.", {
      code: "google_one_tap_unavailable",
      retryable: true,
    });
  }
}

function handleGooglePromptMoment(notification, handlers, finish) {
  if (notification.isNotDisplayed?.() || notification.isSkippedMoment?.()) {
    if (finish()) handlers.onPromptUnavailable?.();
    return;
  }
  if (
    notification.isDismissedMoment?.() &&
    notification.getDismissedReason?.() !== "credential_returned" &&
    finish()
  ) {
    handlers.onPromptDismissed?.();
  }
}

async function createOidcNonce() {
  const nonce = base64Url(crypto.getRandomValues(new Uint8Array(32)));
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(nonce));
  const hashedNonce = Array.from(new Uint8Array(digest), byte =>
    byte.toString(16).padStart(2, "0")
  ).join("");
  return { nonce, hashedNonce };
}

async function createPkce() {
  const verifier = base64Url(crypto.getRandomValues(new Uint8Array(32)));
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return { verifier, challenge: base64Url(new Uint8Array(digest)) };
}

function trustedOAuthUrl(rawUrl) {
  if (typeof rawUrl !== "string" || rawUrl.length > 8192) {
    throw invalidAuthResponse("The authentication service returned an invalid OAuth URL.");
  }
  const providerUrl = new URL(rawUrl);
  if (providerUrl.protocol !== "https:" || providerUrl.username || providerUrl.password) {
    throw invalidAuthResponse("The authentication service returned an untrusted OAuth URL.");
  }
  return providerUrl.href;
}

function currentCallbackUrl(config) {
  const raw = config.getOAuthCallbackUrl();
  nonEmptyString(raw, "OAuth callback URL", 4096);
  const parsed = new URL(raw);
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password ||
    parsed.search ||
    parsed.hash
  ) {
    throw new WebsiteAuthError("The configured OAuth callback URL is invalid.", {
      code: "oauth_callback_invalid",
    });
  }
  return parsed.href;
}

function normalizeCookieSession(payload) {
  const candidate = isRecord(payload) && "session" in payload ? payload.session : payload;
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (
    !isRecord(candidate) ||
    Object.hasOwn(candidate, "accessToken") ||
    Object.hasOwn(candidate, "refreshToken") ||
    candidate.authenticated !== true ||
    typeof candidate.tokenType !== "string" ||
    !/^bearer$/iu.test(candidate.tokenType) ||
    !Number.isSafeInteger(candidate.expiresIn) ||
    candidate.expiresIn <= 0 ||
    candidate.expiresIn > MAX_SESSION_LIFETIME_SECONDS ||
    !Number.isSafeInteger(candidate.expiresAt) ||
    candidate.expiresAt <= 0 ||
    candidate.expiresAt > nowSeconds + MAX_SESSION_LIFETIME_SECONDS
  ) {
    throw new WebsiteAuthError("The authentication service returned an unsafe cookie session.", {
      code: "auth_cookie_session_invalid",
      retryable: true,
    });
  }
  return Object.freeze({
    authenticated: true,
    tokenType: "bearer",
    expiresIn: candidate.expiresIn,
    expiresAt: candidate.expiresAt,
  });
}

function normalizeCookieAuthSuccess(payload) {
  if (!isRecord(payload)) {
    throw invalidAuthResponse("The authentication service returned invalid account data.");
  }
  return Object.freeze({
    session: normalizeCookieSession(payload),
    user: normalizeAuthUser(payload.user),
  });
}

/**
 * Browser client for websites whose Pages boundary owns access and refresh
 * tokens in HttpOnly cookies. Only public session metadata is persisted.
 */
export function createCookieWebsiteAuth(input) {
  const config = normalizeConfig(input);
  const postAuthJson = createAuthJsonRequester(config);
  let memorySession = null;
  let sessionCheck = null;
  let sessionGeneration = 0;

  function purgeLegacyLocalSessions() {
    if (typeof window === "undefined") return;
    for (const key of config.legacyLocalStorageKeys) window.localStorage.removeItem(key);
  }

  function readStoredSession() {
    if (!config.persistSession) return memorySession;
    if (typeof window === "undefined") return null;
    purgeLegacyLocalSessions();
    const raw = window.localStorage.getItem(config.storageKey);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      const result = normalizeCookieAuthSuccess(parsed);
      return Object.freeze({ ...result.session, user: result.user });
    } catch {
      clearStoredSession();
      return null;
    }
  }

  function storeAuthResult(result) {
    if (typeof window === "undefined") return null;
    const normalized = normalizeCookieAuthSuccess(result);
    memorySession = Object.freeze({ ...normalized.session, user: normalized.user });
    if (!config.persistSession) return memorySession;
    purgeLegacyLocalSessions();
    window.localStorage.setItem(config.storageKey, JSON.stringify({
      session: normalized.session,
      user: normalized.user,
    }));
    return Object.freeze({ ...normalized.session, user: normalized.user });
  }

  function clearStoredSession() {
    sessionGeneration++;
    sessionCheck = null;
    memorySession = null;
    if (!config.persistSession) return;
    if (typeof window === "undefined") return;
    window.localStorage.removeItem(config.storageKey);
    purgeLegacyLocalSessions();
  }

  async function loginWithPasswordResult(email, password, captchaToken) {
    return normalizeCookieAuthSuccess(await postAuthJson("/token/password/login", {
      email,
      password,
      ...(captchaToken ? { captchaToken } : {}),
    }));
  }

  async function confirmEmail(tokenHash, options = {}) {
    if (typeof tokenHash !== "string" || !/^[A-Za-z0-9_-]+$/.test(tokenHash)) {
      throw new TypeError("A valid confirmation token is required.");
    }
    const result = await postAuthJson("/token/email/confirm", { tokenHash }, options);
    const normalized = normalizeCookieAuthSuccess(result);
    if (result.grantType !== "email" || !normalized.user.emailConfirmedAt) {
      throw invalidAuthResponse("The authentication service returned invalid confirmation data.");
    }
    return normalized;
  }

  async function signupWithPassword(value) {
    const result = await postAuthJson("/token/password/signup", {
      email: value.email,
      password: value.password,
      displayName: value.displayName,
      ...(value.companyName ? { companyName: value.companyName } : {}),
      redirectTo: value.redirectTo,
      ...(value.captchaToken ? { captchaToken: value.captchaToken } : {}),
    });
    if (typeof result.confirmationRequired !== "boolean") {
      throw invalidAuthResponse("The authentication service returned invalid sign-up data.");
    }
    const auth = result.session === null ? null : normalizeCookieAuthSuccess(result);
    if (result.confirmationRequired !== (auth === null)) {
      throw invalidAuthResponse("The authentication service returned inconsistent sign-up data.");
    }
    return Object.freeze({
      confirmationRequired: result.confirmationRequired,
      session: auth?.session ?? null,
      user: normalizeAuthUser(result.user),
    });
  }

  async function offerGoogleOneTap(handlers, signal) {
    const generation = sessionGeneration;
    if (typeof window === "undefined" || !config.googleClientId || !window.crypto?.subtle) {
      throw new WebsiteAuthError("Native Google sign-in is unavailable in this browser.", {
        code: "google_one_tap_unavailable",
      });
    }
    const identity = googleIdentity();
    if (!identity?.prompt) {
      throw new WebsiteAuthError("Native Google sign-in is temporarily unavailable.", {
        code: "google_one_tap_unavailable",
        retryable: true,
      });
    }
    const nonce = await createOidcNonce();
    if (signal?.aborted) return;
    let settled = false;
    const finish = () => {
      if (settled) return false;
      settled = true;
      signal?.removeEventListener("abort", abort);
      return true;
    };
    const abort = () => {
      if (finish()) identity.cancel?.();
    };
    signal?.addEventListener("abort", abort, { once: true });
    identity.initialize({
      client_id: config.googleClientId,
      callback: response => {
        if (settled) return;
        const token = typeof response?.credential === "string" ? response.credential.trim() : "";
        if (!token) {
          if (finish()) handlers.onError(new WebsiteAuthError(
            "Google did not return a valid credential.",
            { code: "google_credential_missing", retryable: true }
          ));
          return;
        }
        if (!finish()) return;
        handlers.onCredentialReceived();
        void postAuthJson("/token/google/id-token", { token, nonce: nonce.nonce })
          .then(result => {
            if (signal?.aborted || generation !== sessionGeneration) return;
            const auth = normalizeCookieAuthSuccess(result);
            storeAuthResult(auth);
            handlers.onSuccess(auth);
          })
          .catch(error => handlers.onError(error));
      },
      nonce: nonce.hashedNonce,
      auto_select: false,
      cancel_on_tap_outside: true,
      context: "signin",
      itp_support: true,
    });
    identity.prompt(notification => {
      handleGooglePromptMoment(notification, handlers, finish);
    });
  }

  async function startOAuthRedirect(provider) {
    if (typeof window === "undefined") {
      throw new WebsiteAuthError("OAuth sign-in requires a browser.", { code: "browser_required" });
    }
    assertProvider(provider);
    if (!window.crypto?.subtle) {
      throw new WebsiteAuthError("This browser cannot start secure OAuth sign-in.", {
        code: "browser_unsupported",
      });
    }
    googleIdentity()?.cancel?.();
    if (config.persistSession) window.sessionStorage.removeItem(config.oauthPendingKey);
    const redirectTo = currentCallbackUrl(config);
    const pkce = await createPkce();
    const start = await postAuthJson(`/token/${provider}/start`, {
      redirectTo,
      codeChallenge: pkce.challenge,
    });
    const providerUrl = trustedOAuthUrl(start.url);
    const pending = { provider, verifier: pkce.verifier, redirectTo, createdAt: Date.now() };
    if (config.persistSession) window.sessionStorage.setItem(config.oauthPendingKey, JSON.stringify(pending));
    else await postAuthJson("/session/oauth/store", pending);
    return providerUrl;
  }

  async function readOAuthRedirectPending() {
    const raw = config.persistSession ? window.sessionStorage.getItem(config.oauthPendingKey)
      : JSON.stringify((await postAuthJson("/session/oauth/consume", {})).pending);
    if (config.persistSession) window.sessionStorage.removeItem(config.oauthPendingKey);
    if (!raw) return null;
    try {
      const value = JSON.parse(raw);
      if (
        !isRecord(value) ||
        !OAUTH_PROVIDERS.includes(value.provider) ||
        typeof value.verifier !== "string" ||
        !/^[A-Za-z0-9._~-]{43,128}$/u.test(value.verifier) ||
        value.redirectTo !== currentCallbackUrl(config) ||
        typeof value.createdAt !== "number" ||
        Date.now() - value.createdAt < 0 ||
        Date.now() - value.createdAt > OAUTH_CALLBACK_MAX_AGE_MS
      ) return null;
      return value;
    } catch {
      return null;
    }
  }

  function storeRedirectResult(result) {
    if (!config.persistSession) return;
    window.sessionStorage.setItem(config.redirectResultKey, JSON.stringify(result));
  }

  function readAuthRedirectResult() {
    if (typeof window === "undefined") return null;
    if (!config.persistSession) return new URL(window.location.href).searchParams.get("auth") === "failed"
      ? {kind:"error", message:"Sign-in failed. Please try again."} : null;
    const raw = window.sessionStorage.getItem(config.redirectResultKey);
    window.sessionStorage.removeItem(config.redirectResultKey);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      return isRecord(parsed) && ["session", "error"].includes(parsed.kind)
        ? Object.freeze(parsed)
        : null;
    } catch {
      return null;
    }
  }

  async function completeOAuthRedirectCallback(handlers = {}) {
    if (typeof handlers.onSuccess !== 'function') {
      throw new TypeError('OAuth completion requires the authentication flow success handler.');
    }
    if (typeof window === "undefined") return false;
    const generation = sessionGeneration;
    const pending = await readOAuthRedirectPending();
    if (generation !== sessionGeneration) return false;
    const callbackUrl = new URL(window.location.href);
    const oauthError = callbackUrl.searchParams.get("error_description") ??
      callbackUrl.searchParams.get("error");
    const code = callbackUrl.searchParams.get("code");
    if (!pending || oauthError || !code || code.length > 8192) {
      storeRedirectResult({
        kind: "error",
        message: oauthError
          ? "Provider sign-in was cancelled or denied."
          : "The sign-in attempt is missing or has expired. Please try again.",
      });
      if (handlers.onFailure) await handlers.onFailure();
      else window.location.replace(config.oauthFailureUrl);
      return true;
    }
    try {
      const result = await postAuthJson(`/token/${pending.provider}/exchange`, {
        code,
        codeVerifier: pending.verifier,
        redirectTo: pending.redirectTo,
      });
      if (generation !== sessionGeneration) return false;
      storeAuthResult(result);
      storeRedirectResult({ kind: "session" });
      await handlers.onSuccess(result);
    } catch (error) {
      if (generation !== sessionGeneration) return false;
      storeRedirectResult({
        kind: "error",
        message: error instanceof WebsiteAuthError
          ? error.message
          : "Provider sign-in failed. Please try again.",
      });
      if (handlers.onFailure) await handlers.onFailure();
      else window.location.replace(config.oauthFailureUrl);
    }
    return true;
  }

  function getValidStoredSession(options = {}) {
    if (sessionCheck) return sessionCheck;
    const pending = checkSession(options.refresh === true);
    sessionCheck = pending;
    void pending.finally(() => { if (sessionCheck === pending) sessionCheck = null; }).catch(() => {});
    return pending;
  }

  async function checkSession(forceRefresh = false) {
    const generation = sessionGeneration;
    const accept = result => generation === sessionGeneration ? storeAuthResult(result) : null;
    const current = readStoredSession();
    if (!current && config.persistSession && !forceRefresh) return null;
    try {
      if (forceRefresh || !current) return accept(await postAuthJson("/token/refresh", {}));
      if (current.expiresAt <= Math.floor(Date.now() / 1000) + SESSION_REFRESH_LEEWAY_SECONDS) {
        return accept(await postAuthJson("/token/refresh", {}));
      }
      const verification = await postAuthJson("/verify", { includeUser: true });
      if (generation !== sessionGeneration) return null;
      if (verification.valid !== true) {
        clearStoredSession();
        return null;
      }
      return accept({ session: current, user: verification.user ?? current.user });
    } catch (error) {
      if (generation !== sessionGeneration) return null;
      if (error instanceof WebsiteAuthError && error.status === 401) { clearStoredSession(); return null; }
      throw error;
    }
  }

  async function logout() {
    try {
      await postAuthJson("/session/logout", {});
    } finally {
      clearStoredSession();
    }
  }

  return Object.freeze({
    config,
    postAuthJson,
    invalidateSessionChecks() { sessionGeneration++; sessionCheck = null; memorySession = null; },
    requestAccountPasswordRecovery: (email, redirectTo, captchaToken) => postAuthJson('/token/password/recover', {
      email, redirectTo, ...(captchaToken ? { captchaToken } : {}),
    }),
    updateAccountProfile: async input => normalizeAuthUser(await postAuthJson('/account/profile', input)),
    updateAccountPassword: input => postAuthJson('/account/password', input),
    ensureAppAccess: () => postAuthJson('/access/ensure', {}),
    ...recoveryClient(config, postAuthJson, WebsiteAuthError),
    readStoredSession,
    storeAuthResult,
    clearStoredSession,
    loginWithPasswordResult,
    signupWithPassword,
    confirmEmail,
    prepareGoogleOneTap: () => prepareGoogleOneTap(config),
    isGoogleOneTapReady: () => isGoogleOneTapReady(config),
    offerGoogleOneTap,
    startOAuthRedirect,
    completeOAuthRedirectCallback,
    readAuthRedirectResult,
    getValidStoredSession,
    logout,
  });
}
