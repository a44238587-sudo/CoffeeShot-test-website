# Website password recovery

Status: source and configuration prepared. This document does not assert that
SMTP, Supabase redirect settings or its shared reset template have been applied.

## Ownership and configuration

Browser: configure `createWebsiteAuthFlow` using the mandatory fields in
`FLOW.md`, adding `recovery: { enabled: true,
returnUrl: 'https://your-canonical-site.example/auth/reset-password/',
successUrl: '/?auth=sign-in', errorUrl: '/auth/reset-password/' }`.
Set `isRecoveryRoute` to match the configured recovery pathname.
Examples above are placeholders, not registered destinations. Paths for success
and error must be same-origin absolute paths, not protocol-relative URLs. The
site owns navigation and renders errors in its recovery form; the SDK never
navigates automatically after a reset. `errorUrl` is the site's new-link page.

Pages: `createCookiePagesAuthHandler({ appSlug, ..., recovery: { enabled: true,
returnUrls: [/* exact configured HTTPS URLs */], contextMaxAgeSeconds: 600,
cookieName: '__Host-your-app-recovery' } })`.
The cookie name is optional (defaults to `__Host-<appSlug>-recovery`) and must
not equal either normal session cookie. Missing/incomplete recovery configuration
fails clearly when used; unrelated login methods are unchanged.

`auth-supabase-app/recovery-policy.js` owns per-application destinations. There
are separate production, staging and development lists. Empty lists mean not
configured, not permission to infer localhost, OAuth, Origin, Host or `next`.
Production uses exact URLs. Enable `deliveryReady` only after the checklist below.
The private core exchanges with Supabase and stores a temporary recovery grant;
no product tables, memberships, credits or phone numbers are touched.

## HTTP contract

Every operation is POST, application/json, requires an unchanged X-Request-Id,
rejects query parameters/unknown fields/duplicate JSON keys. SDK browser requests
use same-origin credentials and cancellation. Pages additionally requires the
exact configured site Origin and rejects cross-site requests. No browser-supplied
Authorization or userId selects the reset target.

| SDK method / same-origin path under `/api/auth` | app path under `/:appSlug` | core | JSON body | authentication / successful result |
|---|---|---|---|---|
| requestPasswordRecovery / token/password/recover | /token/password/recover | /password/recover | `{email, redirectTo, captchaToken?}` | no session; `{recoveryRequested:true}` |
| verifyPasswordRecovery / token/password/recovery/verify | /token/password/recovery/verify | /password/recovery/verify | `{tokenHash}` | proof; fixed `type:recovery`, private `grantType:recovery`; public `{authorized:true,expiresAt,email}` |
| getPasswordRecoveryContext / token/password/recovery/context | /token/password/recovery/context | /password/recovery/context | `{}` | recovery cookie / private opaque Bearer grant; authorized result or completed result |
| completePasswordRecovery / token/password/recovery/complete | /token/password/recovery/complete | /password/recovery/complete | `{password}` | recovery cookie / grant; `{authorized:false,passwordUpdated:true,sessionsRevoked:boolean}` |
| clearPasswordRecovery / session/recovery/clear | none | none | `{}` | same-origin; expires only recovery cookie; `{cleared:true}` |

Wire responses also have `{ok:true,rid}`. The private verification result has
`{ok:true,rid,grantType:'recovery',recoveryToken,expiresAt,email}`. The opaque
256-bit credential is projected exclusively into a Secure, HttpOnly, SameSite=Lax,
Path=/ `__Host-*` cookie. `expiresAt` is milliseconds since epoch. No Supabase
access token, refresh token, recoveryToken or normal session is returned to JS.
The core calls the same password-update implementation as `/account/password`
with the verified user's access token; that existing authenticated route retains
its current-password/nonce contract. No admin password API is used.

Both workers preserve existing MAX_JSON_BYTES (65,536) and request deadlines.
Pages bounds request bodies to 65,536 bytes and upstream responses to 1,048,576
bytes; the SDK requester owns its existing absolute timeout and cancellation.
No retries are automatic. Requesting another email is an explicit new operation.
Checking context is read-only and repeatable. GET/HEAD never consume a proof.
SDK verification first clears a previous recovery cookie, awaiting acknowledgment,
then sends the proof once. A failed clear must not authorize a previous context.
The UI must not restore an old context when a new unverified link is present.

Completion atomically claims a Durable Object before any password update.
Concurrent requests get `RECOVERY_UNCERTAIN`; after recorded success, a replay
returns that success without another update. A confirmed password-policy rejection
can release the claim. A lost provider response leaves it locked until expiry:
never automatically replay a possibly successful mutation. On a verification
or completion timeout, check context explicitly; if no confirmed state exists,
request a new link. Expired/invalid/already-used proofs intentionally share a
safe error because Supabase does not reliably distinguish those cases.

Errors use `{ok:false,rid,error:{category,code,message,retryable}}`. Added registry
codes: AUTH_CORE.RECOVERY_EXPIRED (401), AUTH_CORE/APP.RECOVERY_UNCERTAIN (409),
AUTH_CORE/APP.RECOVERY_NOT_CONFIGURED (503), AUTH_APP.RECOVERY_REDIRECT_FORBIDDEN
(422), AUTH_APP.RECOVERY_CSRF (403). Existing strict-body errors are 400/413/415/422;
password policy is AUTH_CORE.WEAK_PASSWORD (422), reauthentication 401, provider
quota 503, provider/network failure 502, timeout 504. Browser projection reconstructs
safe messages from a finite registry and never relays raw provider diagnostics.
Mutating ambiguous results are non-retryable. `auth_recovery_context_clear_failed`
is a SDK-local error: reopen the link, do not use a previous recovery context.

## Temporary context and sessions

Core RECOVERY_CONTEXT binding uses PasswordRecoveryContext with SQLite Durable
Objects. RECOVERY_CONTEXT_TTL_SECONDS=600 (valid 1–3600) is required; actual lifetime
is also capped by Supabase access-token expiry. One alarm deletes the record after
expiry, without a cron. Every operation checks expiry even if alarm delivery is
late. Stored data is only the temporary access token, verified user id/email,
expiry and mutation state. No password, TokenHash or refresh token is persisted.
Storage keys hash project URL plus random credential; request URLs never contain
it. On success credentials and identity are removed, retaining only a replay
receipt until expiry. Clearing the browser cookie cannot extend or recover it.

Recovery cookies work across reloads without JS storage or PKCE. With
persistSession:false neither localStorage nor sessionStorage is needed. Recovery
never stores normal login metadata or sets normal access/refresh cookies. A user
already logged into a different account keeps that account's cookies untouched.

After password update, the core attempts Supabase `logout?scope=global` for the
verified identity. `sessionsRevoked:true` means that request returned 204, not
that issued JWTs vanished. Already-issued access JWTs can remain usable until
their expiry, according to consumers' validation and Supabase configuration.
If logout fails, the password change remains successful and sessionsRevoked=false
is shown; do not promise revocation. After success the site invites normal login.
Password identity is shared across sites using the same Supabase project and Auth
user. appSlug isolates business authorization, not the password itself.

## Supabase activation checklist (not applied)

1. Read the effective Auth config and identify which project AUTH_SUPABASE_APP's
   SUPABASE_URL targets. The available Supabase connector identifies project
   deqlqtiewtogpnnlcgxo; the Secret Store value and Auth management config still
   need to be compared by an authorized operator. Do not replace global Site URL.
2. Merge, without deleting other destinations, these exact Redirect URLs:
   - https://esimandco-website.pages.dev/auth/reset-password/
   - https://esimandco-website.pages.dev/fr/auth/reset-password/
   - https://esimandco-website.pages.dev/es/auth/reset-password/
   These complete paths correspond to appSlug telephony. No custom production
   domain, development or staging URL has been supplied for this flow. Configure
   those explicitly in both site and application policy before using them.
3. Inventory compatibility before changing the shared Reset password template.
   Current source inventory: Dictum website actively invokes recovery with slug
   dictumflow and `/dashboard?mode=recovery` on dictumflow.com or
   dictum-website.pages.dev. Those legacy exact destinations remain allowed.
   Its old link/session handling is NOT compatible with this TokenHash page;
   migrate that consumer before applying the shared template. EditGator and
   Zebumail expose pass-through recovery routes, but no active recovery form or
   destination was found in the inspected source. Confirm external API consumers
   with the owner; do not claim an exhaustive inventory of remote clients.
4. Set only Reset password HTML to `reset-password.html`, subject `Reset your
   password`, after consumers are compatible. Do not change confirmation,
   invitation or email-change templates. Convention: RedirectTo is the complete
   HTTPS page URL, no query/fragment. Template appends only
   `#token_hash={{ .TokenHash }}`. It adds no path and uses no fixed product domain.
5. Configure custom SMTP. Required exact fields: smtp_host, smtp_port, smtp_user,
   smtp_pass (secret), smtp_admin_email (From address), smtp_sender_name. Provider,
   sender domain, address and credentials remain unspecified; no provider was
   created. Verify that provider's sender/domain approval and DNS SPF, DKIM and
   DMARC requirements once chosen. Disable click/open tracking and link rewriting
   for authentication email, and confirm fragment preservation on test identities.
   Supabase default SMTP is restricted to project-team recipients and unsuitable
   for real-client production validation. A service acceptance is not delivery.
6. Review existing Auth password policy, CAPTCHA, email rate limits and JWT/session
   expiry. Preserve current settings; do not disable them to pass a test. Core
   passes captchaToken unchanged. The site uses its existing eight-character form
   minimum; Supabase remains authoritative for additional password requirements.
7. Validate delivery/open/reset on test identities across two devices and another
   compatible site, then set telephony deliveryReady=true and deploy the app worker.

## Privacy and infrastructure

Only a URL fragment carries TokenHash, so browsers do not transmit it in the HTTP
URL or Referer to Pages/CDN access logs. The isolated page clears the fragment into
memory immediately, has noindex/no-store/no-referrer and no analytics, pixels,
external fonts or developer UI. Verification bodies carry the proof, never URLs.
Core/app controlled error logging emits correlation/code, never request bodies;
private DO request URLs are constant action paths. No log-tail test using real
proofs was performed. Before enabling delivery, verify account-level Logpush/WAF
body capture and email link rewriting settings, which were not accessible in Auth
configuration tools. Do not put tokens in query strings; nonconforming external
links can already have been logged before page JavaScript cleans them.

## Delivery and rollback

Deploy core (including DO migration), then app route/policy code, publish SDK
0.7.0 source and pack a NEW immutable archive, update each site's checksum,
dependency and lockfile, deploy sites, then configure redirects/SMTP/template in
that order after legacy compatibility. Keep deliveryReady=false until ready.
The private package is distributed by versioned source plus npm-pack input, not
an npm public registry or a mutable node_modules patch.

Rollback by a new forward commit restoring the previous consumer dependency and
setting deliveryReady=false. Preserve old archives/checksums. Do not drop the
Durable Object migration/class during its lifetime; expiry drains old contexts.
Restore the previous shared template only after checking which consumers use it.
Do not rewrite old versions or roll back unrelated auth and business changes.

Official references:
- https://supabase.com/docs/guides/auth/auth-email-templates
- https://supabase.com/docs/guides/auth/redirect-urls
- https://supabase.com/docs/guides/auth/auth-smtp
- https://supabase.com/docs/guides/auth/password-security
- https://supabase.com/docs/guides/auth/sessions
