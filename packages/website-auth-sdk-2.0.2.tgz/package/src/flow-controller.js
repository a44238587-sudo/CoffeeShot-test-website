import { WebsiteAuthError } from './cookie-client.js';

/** Framework-neutral auth state machine. Dependencies are injected for remote unit tests. */
export function createFlowController(config, client, host) {
  if (typeof config.getSuccessUrl !== 'function') {
    throw new TypeError('getSuccessUrl is required.');
  }
  const listeners = new Set();
  let generation = 0;
  let sessionEpoch = 0;
  let disposed = false;
  let verification = null;
  let actionAbort = null;
  let activeRequest = null;
  let signedOut = false;
  let callbackCompletion = null;
  let hidden = false;
  let state = Object.freeze({
    phase: 'checking', session: null, user: null, action: null,
    busy: false, error: null, message: null, canRenderProtected: false,
    recovery: null,
  });
  function publish(patch) {
    if (disposed) return;
    state = Object.freeze({ ...state, ...patch });
    for (const listener of listeners) listener(state);
  }
  function current(ticket) { return !disposed && ticket === generation; }
  function accept(result) {
    if (state.user?.id !== result.user.id) sessionEpoch++;
    signedOut = false;
    const session = client.storeAuthResult(result);
    publish({ phase: 'authenticated', session, user: result.user,
      canRenderProtected: true, recovery: null });
    return session;
  }
  function target(value) {
    if (typeof value !== 'string' || !value.trim()) {
      throw new TypeError('Authentication destination must be a nonempty string.');
    }
    const url = new URL(value, host.url());
    if (url.origin !== new URL(host.url()).origin || url.username || url.password) {
      throw new TypeError('Authentication navigation must remain same-origin.');
    }
    return url.href;
  }
  function navigate(value) {
    const destination = target(value);
    if (destination !== host.url()) return host.replace(destination);
  }
  async function navigateAuthenticated(ticket) {
    const destination = await config.getSuccessUrl();
    if (current(ticket)) await navigate(destination);
  }
  async function authenticated(result, action) {
    const ticket = generation;
    accept(result);
    await config.onAuthenticated?.(result, action);
    if (!current(ticket)) return null;
    await navigateAuthenticated(ticket);
    if (!current(ticket)) return null;
    return result;
  }
  async function enforceRoute() {
    if (state.phase === 'anonymous' && config.isProtectedRoute?.(new URL(host.url()))) {
      return navigate(config.signedOutUrl);
    }
    if (state.canRenderProtected && config.isAuthRoute?.(new URL(host.url()))) {
      const ticket = generation;
      return navigateAuthenticated(ticket);
    }
  }
  async function perform(action, operation, { minimum = true, success } = {}) {
    if (disposed) throw new WebsiteAuthError('Authentication flow is disposed.', { code: 'auth_flow_disposed' });
    if (state.busy) throw new WebsiteAuthError('Another authentication action is pending.', { code: 'auth_flow_busy' });
    const ticket = ++generation;
    const started = host.now();
    actionAbort = new AbortController();
    publish({ action, busy: true, error: null, message: null });
    try {
      const request = Promise.resolve(operation(actionAbort.signal));
      activeRequest = request;
      const result = await request;
      if (minimum) await host.wait(Math.max(0, 600 - (host.now() - started)));
      if (!current(ticket)) return null;
      return success ? await success(result) : result;
    } catch (error) {
      if (minimum) await host.wait(Math.max(0, 600 - (host.now() - started)));
      if (current(ticket)) publish({ error });
      throw error;
    } finally {
      if (current(ticket)) {
        actionAbort = null;
        activeRequest = null;
        publish({ action: null, busy: false });
      }
    }
  }
  function verify(options = {}) {
    if (signedOut) return Promise.resolve(null);
    if (hidden && config.gateWhenHidden) return Promise.resolve(null);
    if (verification) return verification;
    if (state.busy || disposed) return Promise.resolve(state.session);
    const ticket = generation;
    if (state.phase !== 'authenticated') publish({ phase: 'checking', canRenderProtected: false, error: null });
    const pending = client.getValidStoredSession(options).then(async session => {
      if (!current(ticket)) return null;
      if (state.user?.id !== session?.user.id) sessionEpoch++;
      const recoveryRoute = !!session && config.isRecoveryRoute?.(new URL(host.url())) === true;
      publish({ phase: recoveryRoute ? 'recovery' : session ? 'authenticated' : 'anonymous', session,
        user: session?.user ?? null, canRenderProtected: !!session && !recoveryRoute });
      await enforceRoute();
      return session;
    }).catch(error => {
      if (current(ticket)) publish({ phase: 'unavailable', error, canRenderProtected: false });
      throw error;
    }).finally(() => { if (verification === pending) verification = null; });
    verification = pending;
    return pending;
  }
  const flow = {
    get state() { return state; },
    subscribe(listener) {
      listeners.add(listener);
      listener(state);
      return () => listeners.delete(listener);
    },
    async start() {
      const url = new URL(host.url());
      const callback = new URL(config.getOAuthCallbackUrl(), url);
      const response = url.searchParams.has('code') || url.searchParams.has('error');
      if (url.pathname === callback.pathname && response) {
        return flow.completeOAuthRedirectCallback();
      }
      if (!config.isRecoveryRoute?.(url)) void client.prepareGoogleOneTap().catch(() => {});
      const redirect = client.readAuthRedirectResult();
      const session = await verify();
      if (redirect?.kind === 'error') publish({ message: redirect.message });
      return session;
    },
    verify,
    routeChanged() { return verify(); },
    pageShown() { return verify(); },
    visibilityChanged(isHidden) {
      hidden = isHidden;
      if (isHidden) {
        if (config.gateWhenHidden && !state.busy) {
          ++generation; verification = null;
          publish({ phase: 'checking', canRenderProtected: false });
        }
        return Promise.resolve();
      }
      return verify();
    },
    storageChanged(key) {
      if (config.persistSession === false || (key !== null && key !== config.storageKey)) return Promise.resolve();
      ++generation;
      ++sessionEpoch;
      signedOut = false;
      actionAbort?.abort();
      client.invalidateSessionChecks();
      verification = null;
      publish({ phase: 'checking', session: null, user: null, canRenderProtected: false, busy: false, action: null });
      return verify();
    },
    invalidateSession() {
      ++generation;
      ++sessionEpoch;
      signedOut = true;
      actionAbort?.abort();
      client.clearStoredSession();
      publish({ phase: 'anonymous', session: null, user: null,
        canRenderProtected: false, recovery: null, busy: false, action: null });
      enforceRoute();
    },
    login(email, password, captchaToken) {
      return perform('login', async signal => {
        const captcha = captchaToken ?? (config.getCaptchaToken ? await config.getCaptchaToken(signal) : undefined);
        signal.throwIfAborted();
        return client.loginWithPasswordResult(email, password, captcha);
      }, {
        success: result => authenticated(result, 'login'),
      });
    },
    signup(input) {
      return perform('signup', async signal => {
        const captchaToken = input.captchaToken ?? (config.getCaptchaToken ? await config.getCaptchaToken(signal) : undefined);
        signal.throwIfAborted();
        return client.signupWithPassword({ ...input, captchaToken });
      }, {
        async success(result) {
          if (result.confirmationRequired) publish({ message: 'confirmation-required' });
          else await authenticated(result, 'signup');
          return result;
        },
      });
    },
    oauth(provider) {
      // Read readiness synchronously during the explicit provider click.
      const native = provider === 'google' && client.isGoogleOneTapReady();
      return perform(`oauth:${provider}`, signal => native
        ? new Promise((resolve, reject) => {
          let settled = false;
          const once = fn => value => { if (!settled) { settled = true; fn(value); } };
          client.offerGoogleOneTap({
            onCredentialReceived() {},
            onSuccess: once(result => resolve({ result })), onError: once(reject),
            onPromptDismissed: once(() => resolve({ dismissed: true })),
            onPromptUnavailable: once(() => client.startOAuthRedirect(provider)
              .then(url => resolve({ url }), reject)),
          }, signal).catch(reject);
          signal.addEventListener('abort', () => reject(signal.reason), { once: true });
        })
        : client.startOAuthRedirect(provider).then(url => ({ url })), {
          async success(outcome) {
            if (outcome.result) await authenticated(outcome.result, 'oauth');
            if (outcome.url) host.assign(outcome.url);
            return outcome;
          },
        });
    },
    completeOAuthRedirectCallback() {
      callbackCompletion ??= perform('callback', () => {
        const ticket = generation;
        return client.completeOAuthRedirectCallback({
          onSuccess: result => current(ticket) ? authenticated(result, 'oauth') : null,
          onFailure: () => current(ticket) ? navigate(config.oauthFailureUrl) : null,
        });
      }, { minimum: false });
      return callbackCompletion;
    },
    async logout() {
      const previous = activeRequest;
      signedOut = true;
      ++generation;
      ++sessionEpoch;
      actionAbort?.abort();
      client.clearStoredSession();
      publish({ phase: 'anonymous', session: null, user: null,
        canRenderProtected: false, recovery: null, busy: false, action: null });
      await perform('logout', async () => {
        // A preceding login response may set cookies; clear them afterwards.
        await previous?.catch(() => {});
        await client.logout();
      }, { minimum: false });
      navigate(config.signedOutUrl);
    },
    confirmEmail(tokenHash) {
      return perform('confirm-email', signal => client.confirmEmail(tokenHash, { signal }), {
        minimum: false, success: result => authenticated(result, 'confirm-email'),
      });
    },
    requestPasswordRecovery(email, options = {}) {
      return perform('request-recovery', signal => client.requestPasswordRecovery(email, { ...options, signal: options.signal ? AbortSignal.any([signal, options.signal]) : signal }));
    },
    verifyPasswordRecovery(tokenHash, options = {}) {
      return perform('verify-recovery', signal => client.verifyPasswordRecovery(tokenHash, {
        signal: options.signal ? AbortSignal.any([signal, options.signal]) : signal,
      }), {
        minimum: false, success(recovery) {
          publish({ phase: 'recovery', recovery, session: null, user: null, canRenderProtected: false });
          return recovery;
        },
      });
    },
    getPasswordRecoveryContext(options = {}) {
      return perform('recovery-context', signal => client.getPasswordRecoveryContext({
        signal: options.signal ? AbortSignal.any([signal, options.signal]) : signal,
      }), {
        minimum: false, success(recovery) {
          publish({ phase: 'recovery', recovery, session: null, user: null, canRenderProtected: false });
          return recovery;
        },
      });
    },
    completePasswordRecovery(password, options = {}) {
      return perform('complete-recovery', signal => client.completePasswordRecovery(password, {
        signal: options.signal ? AbortSignal.any([signal, options.signal]) : signal,
      }), {
        success(result) {
          client.clearStoredSession();
          publish({ phase: 'anonymous', session: null, user: null, recovery: null, canRenderProtected: false });
          return result;
        },
      });
    },
    clearPasswordRecovery() {
      return perform('clear-recovery', signal => client.clearPasswordRecovery({ signal }), { minimum: false });
    },
    requestAccountPasswordRecovery(email, redirectTo, captchaToken) {
      // Existing account recovery destinations remain Worker-allowlisted.
      return perform('request-recovery', () => client.requestAccountPasswordRecovery(email, target(redirectTo), captchaToken));
    },
    updateAccountProfile(input) {
      return perform('update-profile', async () => {
        const session = await client.getValidStoredSession();
        if (!session) throw new WebsiteAuthError('An authenticated session is required.', { code: 'auth_session_required', status: 401 });
        return { session, user: await client.updateAccountProfile(input) };
      }, { minimum: false, success(result) { accept(result); return result.user; } });
    },
    updateAccountPassword(input) {
      if (!input.currentPassword && !config.isRecoveryRoute?.(new URL(host.url()))) {
        return Promise.reject(new WebsiteAuthError('A recovery route is required.', { code: 'auth_recovery_required', status: 403 }));
      }
      return perform('update-password', () => client.updateAccountPassword(input), { minimum: false });
    },
    ensureAppAccess() {
      return flow.runAuthenticated(() => client.ensureAppAccess());
    },
    async runAuthenticated(operation) {
      const session = await verify();
      if (!session || !state.canRenderProtected) throw new WebsiteAuthError('An authenticated session is required.', { code: 'auth_session_required', status: 401 });
      const epoch = sessionEpoch;
      // Execute exactly once: automatic replay may duplicate business writes.
      const assertCurrentSession = () => {
        if (disposed || epoch !== sessionEpoch || !state.canRenderProtected) throw new WebsiteAuthError('The session changed during the request.', { code: 'auth_session_changed', status: 401 });
      };
      let result;
      try { result = await operation(session); }
      catch (error) { assertCurrentSession(); throw error; }
      assertCurrentSession();
      return result;
    },
    dispose() {
      ++generation;
      actionAbort?.abort();
      disposed = true;
      listeners.clear();
    },
  };
  return Object.freeze(flow);
}
